#include "fightscene.h"
#include <QLabel>
#include <QPushButton>
#include <QDebug>
#include <QPixmap>
#include <QPainter>
#include <QPoint>
#include <QKeyEvent>
#include <QTimer>

FightScene::FightScene(Monster*monster,QWidget *parent) : QWidget(parent)
{
    //获得怪物信息
    this->monster=monster;
    //设置基础属性
    this->resize(681,521);
    //this->setFocusPolicy(Qt::StrongFocus);//设置 焦点在战斗界面
    //设置QPixMap为底层画布
    pixMap=QPixmap(681,521);
    pixMap.fill(Qt::transparent);//设置透明  暂时没有背景图

    //设置主角and怪物HP
    this->currentRoleHP=player.getHp();
    this->currentMonsterHP=monster->getHp();
    //连接可攻击信号和攻击函数
    connect(this,&FightScene::roleFightSignal,this,&FightScene::roleAction);
    connect(this,&FightScene::BossFightSignal,this,&FightScene::BossAction);
    connect(this,&FightScene::roleFailSignal,this,&FightScene::FailView);
    connect(this,&FightScene::victorySignal,this,&FightScene::victoryView);

    widgetsSet();
    //设置QTimer
    roleTimer=new QTimer(this);
    roleTimer->start(100);
    connect(roleTimer,&QTimer::timeout,this,[=](){
        BossX-=this->monster->getSpeed();
        roleX-=player.getSpeed();
//        attack->setFocus();
        update();
    });

}

void FightScene::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    painter.drawPixmap(0,0,681,521,pixMap);
    if(flag==0){
        QImage image;
        //绘制背景
        image.load(":/fightingBackground/Image/FightingBack/cave1.png");
        painter.drawImage(0,0,image.scaled(this->width(),this->height()));
        //绘制人物和boss
        image.load(":/role/Image/Role/2.png");
        painter.drawImage(450,300,image.scaled(80,80));
        QString Boss=":/Battlers/Image/Battlers/7Boss/";
        Boss+=QString::number(this->monster->getID())+".png";
        image.load(Boss);
        painter.drawImage(20,100,image.scaled(350,280).mirrored(true,false));//镜面翻转


        //右上角绘制人物状态（HP之类的）
        image.load(":/role/Image/Role/1.png");
        painter.drawImage(500,10,image);
        QPen pen;
        pen.setWidth(20);
        pen.setColor(Qt::cyan);
        painter.setPen(pen);
        painter.drawLine(550,20,650,20);
        if(currentRoleHP*1.0/player.getHp()*100>=50)
            pen.setColor(Qt::green);
        else if(currentRoleHP*1.0/player.getHp()*100>=20)
            pen.setColor(Qt::yellow);
        else
            pen.setColor(Qt::red);
        painter.setPen(pen);
        if(currentRoleHP<0){
            currentRoleHP=0;//避免反向划线
        }
        painter.drawLine(550,20,550+currentRoleHP*1.0/player.getHp()*100,20);//血条长度=当前血量占总血量的多少*100像素
        pen.setColor(Qt::black);
        painter.setPen(pen);
        painter.drawText(QPoint(550,25),QString::number(currentRoleHP)+"/"+QString::number(player.getHp()));//血量的文字
        //绘制进度条
        pen.setColor(Qt::cyan);
        pen.setWidth(3);
        painter.setPen(pen);
        painter.drawLine(50,40,300,40);
        if(roleX<=30){
            //roleTimer->stop();
            emit roleFightSignal();//发送可攻击信号
            roleX=270;

        }
        if(BossX<=30){
            emit BossFightSignal();//发送可攻击信号
            BossX=270;       
        }
        image.load(":/small/Image/smallIcon/skull.png");
        painter.drawImage(BossX,0,image.scaled(30,30));
        image.load(":/small/Image/smallIcon/1.png");
        painter.drawImage(roleX,45,image.scaled(30,30));
    }


}
//控件设置
void FightScene::widgetsSet(){
    attack=new QPushButton(this);
    run=new QPushButton(this);
    back=new QPushButton(this);
    attack->hide();//初始设为不可见
    run->hide();
    back->hide();
    connect(this,&FightScene::roleFightSignal,this,[=](){
        run->show();
        attack->show();
    });
    //攻击按键设置
    attack->setText("攻击");
    attack->move(540,300);
    connect(attack,&QPushButton::clicked,this,[=](){
        this->currentMonsterHP-=100;
        //this->currentMonsterHP-=player.getAttack()*1.0/(1+0.05*monster->getDefend());
        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;
        if(currentMonsterHP<=0){
            run->hide();
            attack->hide();
            QTimer* tempTimer=new QTimer(this);
            tempTimer->start(2500);
            connect(tempTimer,&QTimer::timeout,this,[=](){
                emit victorySignal();
            });
        }else{
            roleTimer->start(100);
            this->setFocus();
            run->hide();
            attack->hide();
        }
    });
    //逃跑按键设置
    run->setText("逃跑");
    run->move(540,350);
    connect(run,&QPushButton::clicked,this,[=](){
        qDebug()<<"你逃跑了";
        run->hide();
        attack->hide();
        roleTimer->stop();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(2500);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            emit roleFailSignal();

        });
    });
    //返回地图按键
    back->setText("返回地图");
    back->move(this->width()/2-50,this->height()-50);
    connect(back,&QPushButton::clicked,this,[=](){
        this->hide();
        emit backMap();

    });
}



//以下都是槽函数
void FightScene::roleAction(){

    roleTimer->stop();
    attack->setFocus();//每次重新设置攻击键为焦点
}

void FightScene::BossAction(){
    qDebug()<<"Boss打了你一拳"<<currentRoleHP;
    //player.setHp(player.getHp()-20);
    currentRoleHP-=monster->getAttack()/(1+0.05*player.getDefend());//攻击伤害计算  attack/(1+n*defend)  此处n=0.05  可设置  n越大护甲减免伤害效益越高
    update();
    if(currentRoleHP<=0){
        roleTimer->stop();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(2500);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            emit roleFailSignal();
            roleTimer->stop();
        });
    }


}

void FightScene::FailView(){
    QImage image;
    image.load(":/fightingBackground/Image/GameOver/gameover.png");
    QPainter painter(&pixMap);
    painter.drawImage(QPoint(0,0),image.scaled(this->width(),this->height()));
    flag=1;//战斗结束
    update();
    back->show();
    back->setFocus();
    attack->hide();
    run->hide();
}
//胜利结算界面  暂时先这样
void FightScene::victoryView(){
    QImage image;
    image.load(":/fightingBackground/Image/GameOver/victory.png");
    QPainter painter(&pixMap);
    QPen pen;
    pen.setColor(Qt::cyan);
    painter.setPen(pen);
    QBrush brush(Qt::cyan);
    brush.setStyle(Qt::Dense3Pattern);
    painter.setBrush(brush);
    painter.drawRect(QRect(0,0,this->width(),this->height()));
    painter.drawImage(QPoint(0,0),image);
    flag=1;//战斗结束
    update();
    back->show();
    back->setFocus();
    attack->hide();
    run->hide();

}

//貌似不需要了
//void FightScene::keyPressEvent(QKeyEvent *event){
//    switch (event->key()) {
//    case Qt::Key_Up:        // 向上移动
//        qDebug()<<"up";
//        break;
//    case Qt::Key_Down:      // 向下移动
//        qDebug()<<"down";
//        break;
//    case Qt::Key_Left:      // 向左移动
//        qDebug()<<"left";
//        break;
//    case Qt::Key_Right:     // 向右移动
//        qDebug()<<"right";
//        break;
//    case Qt::Key_Space:
//        qDebug()<<"Space";
//        break;
//    default:
//        break;
//    }
//}
