#ifndef ROLE_H
#define ROLE_H
#include <QString>
class Role{

public:
    Role(){}
    ~Role(){}
    // 设置属性
    void setHp(int hp){this->hp = hp;}
    void setAttack(int attack){this->attack = attack;}
    void setDefend(int defend){this->defend = defend;}
    void setExp(int exp){this->exp = exp;}
    void setCrit(int crit){this->crit = crit;}
    void setMoney(int money){this->money = money;}
    void setSpeed(int speed){this->speed=speed;}//***新添
    void setName(QString name){this->name=name;}//***新添
    // 获取属性
    int getHp(){return hp;}
    int getAttack(){return attack;}
    int getDefend(){return defend;}
    int getExp(){return exp;}
    int getCrit(){return crit;}
    int getMoney(){return money;}
    int getSpeed(){return speed;}//***新添
    QString getName(){return name;}//***新添
private:
    int hp;     // 生命值
    int attack; // 攻击力
    int defend; // 防御力
    int exp;    // 经验值
    int crit;   // 暴击率
    int money;  // 金钱数量
    int speed;  //速度   ****新添
    QString name;//名字   ****新添
};

#endif // ROLE_H
