#ifndef MONSTER_H
#define MONSTER_H

#include "Role.h"
#include <QString>
class Monster : public Role
{
    struct Difficulty{
        int hp; //生命值
        int attack; // 攻击力
        int defend; // 防御力
    };

public:
    Monster();
    ~Monster();
    //************
    void setSneer(QString sneer){this->sneer=sneer;};
    void setID(int ID){this->ID=ID;};

    QString getSneer(){return this->sneer;};
    int getID(){return this->ID;};

    struct Difficulty difficult[3]={{0,0,0},
                                    {100,10,6},
                                    {200,20,12}};

// 细节部分暂未想好，等实现了具体功能再看
private:
    int ID;
    QString sneer;
};

#endif // MONSTER_H
