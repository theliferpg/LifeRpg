
#include <iostream>
#include <fstream>
#include <sstream>
#include <QPixmap>
#include <QDebug>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "player.h"
#include "monster.h"
#include "fightscene.h"
#include "menuscene.h"
#include "start.h"

using namespace std;

// Constants
const int kPixlen = 32;           // 图块像素大小
const int kOffsetX = 0;           // x轴偏移量
const int kOffsetY = 0;           // y轴偏移量
const int kDecimal = 10;          // 十进制系统设定

extern Player player;   // 玩家
extern int mmap[20][15][10]; // 地图，横坐标，纵坐标，地图编号


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    statusBar()->hide();

    initMap();
    //getMonstersFromFile();
    //player.ChooseVocation(1);

    scene = new QGraphicsScene;
    view = new View(this);

    scene->setSceneRect(0,0,640,480); // 设置画布
    scene->addPixmap(QPixmap(":/map/Image/Map/test1.png"));
    view->setScene(scene);
    view->setMinimumSize(400,400);
    view->SetStatus("main");

    view->hide();

    Start=new startscene(this);
    Start->show();

    Menuscene=new menuscene(this);
    Menuscene->hide();

    chooseDifficult=new chooseDifficultyScence(this);//难度选择界面***********************************
    chooseDifficult->hide();

    chooseVocation=new chooseVocationScence(this);//职业选择界面**************************************
    chooseVocation->hide();

    connect(view, SIGNAL(change()), this, SLOT(slotDrawScene()));
    connect(view, SIGNAL(move(int, int)), this, SLOT(slotMovePlayerItem(int, int)));    // 移动连接槽
    connect(view, SIGNAL(fight(int)), this, SLOT(slotDrawFight(int)));                   // 显示战斗界面

    connect(Start,&startscene::enter,this,&MainWindow::slotChooseVocationOut);      //
    connect(chooseVocation,SIGNAL(chooseVocation(int)),this,SLOT(slotChooseDifficultOut(int)));

    connect(chooseDifficult,SIGNAL(chooseDifficulty(int)),this,SLOT(slotstartGame(int)));       //难度选择之后进入游戏

    connect(view,&View::MenuOut,this,&MainWindow::slotMenuOut);             // 召唤菜单栏
    connect(Menuscene,&menuscene::viewOut,this,&MainWindow::slotViewOut);   // 关闭菜单栏

    AddPlayerItem(player.GetPosx(),player.GetPosy(),1);

    setCentralWidget(view);
    resize(642,482);
    setWindowTitle(tr("The Life RPG"));

//    //战斗画面测试
//    view->hide();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initMap(){
    ifstream in("C:\\Users\\xuehuijie\\Desktop\\TLR v0.2\\TLR v0.2\\map.txt");
    ofstream out("C:\\Users\\xuehuijie\\Desktop\\TLR v0.2\\TLR v0.2\\ttttt.txt");
    if(out.is_open()){

    }
    string line;
    int i = 0;
    if(!in.is_open()){
        qDebug() << "Error";
        return;
    }
    while(getline(in, line)){
        int j = 0;
        stringstream ss(line); string token;
        while(ss >> token){
            mmap[j++][i][0] = atoi(token.c_str());
        }
        i++;
    }
}

void MainWindow::slotstartGame(int num)
{
    view->SetStatus("main");
    slotDrawScene();
    view->setFocus();
    view->show();
    chooseDifficult->hide();
    numberOfDifficulty=num;
    getMonstersFromFile();

}

void MainWindow::slotMenuOut()
{
    view->hide();
    view->SetStatus("menu");
    Menuscene->repaint();//为了更新属性的数据
    Menuscene->show();
    Menuscene->SetFoucs();
}

void MainWindow::slotViewOut()
{
    Menuscene->hide();
    view->SetStatus("main");
    view->show();
    view->setFocus();
}
//*****************************************************新增的难度选择
void MainWindow::slotChooseDifficultOut(int num)
{
    chooseVocation->hide();
    view->SetStatus("choose");
    chooseDifficult->show();
    numOfchooseVocation=num;
    player.ChooseVocation(num);
}

void MainWindow::slotChooseVocationOut()
{
    Start->hide();
    chooseVocation->show();
}

void MainWindow::slotDrawScene() {          // 绘制图像
    if (view->GetStatus() != "main") return;
    scene->clear();
    scene->addPixmap(QPixmap(":/map/Image/Map/test1.png"));
    AddPictureItem(0, 0, "tile");
    for (int i = 0; i < 20; i++)
        for (int j = 0; j < 15; j++)
            AddMapItem(i, j, mmap[i][j][player.GetFloor()]);
    AddPlayerItem(player.GetPosx(), player.GetPosy(), player.GetToward());
}

void MainWindow::slotMovePlayerItem(int x, int y) {             // 移动玩家图像
    if (playerItem->zValue() == 0) {
        playerItem->moveBy(x*kPixlen, y*kPixlen);
        player.SetPosx(player.GetPosx() + x);
        player.SetPosy(player.GetPosy() + y);
        mmap[player.GetPosx()][player.GetPosy()][player.GetFloor()] = 0;
    }
}

void MainWindow::slotDrawFight(int num){
    view->hide();

    fightScene=new FightScene(monsters[0]);
    fightScene->setParent(this);
    connect(fightScene,&FightScene::backMap,this,&MainWindow::slotBackMapFromFight);  // 连接战斗槽
    fightScene->show();
}

void MainWindow::slotBackMapFromFight(){                                     //****************我加的槽函数
    delete fightScene;
    view->setFocus();
    view->SetStatus("main");
    view->show();
}

void MainWindow::AddMapItem(int x, int y, int num) {            // 添加地图物块
    QGraphicsPixmapItem *item = scene->addPixmap(QPixmap(":/images/" ));
    if(num == 77) item = scene->addPixmap(QPixmap(":/role/Image/Role/Ghost1.png"));
    item->setPos(x*kPixlen, y*kPixlen);
}

void MainWindow::AddPictureItem(int x, int y, QString str) {    // 添加一些可能需要的背景
    QGraphicsPixmapItem *item = scene->addPixmap(QPixmap(":/images/" + str));
    //item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setPos(x-kOffsetX,y-kOffsetY);
}

void MainWindow::AddPlayerItem(int x, int y, int toward) {      // 添加玩家物体
    QString str = ":/role/Image/Role/" + QString::number(toward) + ".png";
    playerItem = scene->addPixmap(QPixmap(str));
    playerItem->setPos(x*kPixlen-kOffsetX, y*kPixlen-kOffsetY);
}

void MainWindow::Clear() {              // 清空界面
    QList<QGraphicsItem*> listItem = scene->items();
    while(!listItem.empty()) {
        scene->removeItem(listItem.at(0));
        listItem.removeAt(0);
    }
}

bool MainWindow::getMonstersFromFile(){
    std::ifstream infile("C:\\Users\\xuehuijie\\Desktop\\TLR v0.2\\TLR v0.2\\monster.txt", std::ios::in);
    if (!infile.is_open()) {
        qDebug() << "File failed to be opened." ;
        return false;
    }
    for(int i=0;i<7;i++)
        monsters[i]=new Monster;
    char buf[1000]; // 申请足够放入一专行数据的大小
    infile.getline(buf, 1000);//跳过第一行
    int count = 0;
    std::string name;
    std::string sneer;
    int ID=0,attack=0,defend=0,exp=0,money=0,speed=0,HP=0;
    while (!infile.eof()) {
        infile >>ID>>name>>HP>>attack>>defend>>money>>speed>>sneer>>exp;
        monsters[count]->setID(ID);
        monsters[count]->setName(QString::fromStdString(name));
        monsters[count]->setHp(HP+monsters[count]->difficult[numberOfDifficulty].hp);
        monsters[count]->setAttack(attack+monsters[count]->difficult[numberOfDifficulty].attack);
        monsters[count]->setDefend(defend+monsters[count]->difficult[numberOfDifficulty].defend);
        monsters[count]->setMoney(money);
        monsters[count]->setSpeed(speed);
        monsters[count]->setExp(exp);
        monsters[count]->setSneer(QString::fromStdString(sneer));
        //qDebug()<<monsters[count]->getAttack();
        count++;
    }
    infile.close();
    return true;
}
