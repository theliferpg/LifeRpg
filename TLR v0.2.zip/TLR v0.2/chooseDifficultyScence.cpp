#include"chooseDifficultyScence.h"

chooseDifficultyScence::chooseDifficultyScence(QWidget *parent)
{
    this->setParent(parent);
    this->resize(640,480);

    widgetsSet();
}

void chooseDifficultyScence::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,642,482,pixMap);
    QImage image;
    image.load(":/fightingBackground/Image/FightingBack/building3.png");
    painter.drawImage(0,0,image.scaled(this->width(),this->height()));
}

void chooseDifficultyScence::widgetsSet()
{
     QFont ft("Microsoft YaHei",20,75);

   QLabel *label=new QLabel(this);

    label->setText("难度选择");
    label->setFont(ft);
    label->setGeometry(rect().x()+210,rect().y()+130,200,50);

    label->setStyleSheet("font-size:50px;color:white");

    esayButton=new QPushButton(this);
    commonButton=new QPushButton(this);
    difficultButton=new QPushButton(this);

    esayButton->setText("简单");
    esayButton->move(210,200);
    esayButton->setFont(ft);
    esayButton->setStyleSheet("background: rgb(255,255,255)");
    esayButton->setFixedSize(200,50);
    connect(esayButton,&QPushButton::clicked,this,[=](){
        qDebug()<<"难度选择简单";
        emit chooseDifficulty(0);
    });

    connect(esayButton,&QPushButton::pressed,this,[=](){
        esayButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(esayButton,&QPushButton::released,this,[=](){
        esayButton->setStyleSheet("background: rgb(255,255,255)");
    });

    commonButton->setText("一般");
    commonButton->move(210,275);
    commonButton->setFixedSize(200,50);
    commonButton->setFont(ft);
    commonButton->setStyleSheet("background: rgb(255,255,255)");

    connect(commonButton,&QPushButton::clicked,this,[=](){

        qDebug()<<"难度选择一般";
        emit chooseDifficulty(1);
    });

    connect(commonButton,&QPushButton::pressed,this,[=](){
        commonButton->setStyleSheet("background: rgb(	#191970)");
    });

    connect(commonButton,&QPushButton::released,this,[=](){
        commonButton->setStyleSheet("background: rgb(255,255,255)");
    });


    difficultButton->setText("困难");
    difficultButton->move(210,350);
    difficultButton->setFixedSize(200,50);
    difficultButton->setFont(ft);
    difficultButton->setStyleSheet("background: rgb(255,255,255)");

    connect(difficultButton,&QPushButton::clicked,this,[=](){

        qDebug()<<"难度选择困难";
        emit chooseDifficulty(2);
    });

    connect(difficultButton,&QPushButton::pressed,this,[=](){
        difficultButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(difficultButton,&QPushButton::released,this,[=](){
        difficultButton->setStyleSheet("background: rgb(255,255,255)");
    });
}
