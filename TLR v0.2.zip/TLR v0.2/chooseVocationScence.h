#ifndef CHOOSEVOCATIONSCENCE_H
#define CHOOSEVOCATIONSCENCE_H
#include <QWidget>
#include<QPushButton>
#include<QPainter>
#include <QDebug>
#include "ui_mainwindow.h"
#include <QLabel>

class chooseVocationScence : public QWidget
{
    Q_OBJECT
public:
    explicit chooseVocationScence(QWidget *parent = nullptr);
    void widgetsSet();
    void paintEvent(QPaintEvent *event);

signals:
   void chooseVocation(int num);

public slots:

private:
    QPushButton *vocation1Button;
    QPushButton *vocation2Button;
    QPushButton *vocation3Button;
    QPushButton *vocation4Button;
    QPixmap pixMap;
};
#endif // CHOOSEVOCATIONSCENCE_H
