#include"start.h"
//构造函数
startscene::startscene(QWidget *parent)
{
     this->setParent(parent);
     this->resize(640,480);
     connect(this, SIGNAL(enter()), this, SLOT(enterGame()));
     connect(this, SIGNAL(save()), this, SLOT(saveGame()));
     connect(this, SIGNAL(quit()), this, SLOT(quitGame()));

     widgetsSet();
}

void startscene::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,642,482,pixMap);
    QImage image;
    image.load(":/startbacking/Image/startbacking/start.png");
    painter.drawImage(0,0,image.scaled(this->width(),this->height()));
}

//设置控件
void startscene::widgetsSet()
{
    enterButton=new QPushButton(this);
    saveButton=new QPushButton(this);
    quitButton=new QPushButton(this);

    QFont ft("Microsoft YaHei",20,75);

    enterButton->setText("进入游戏");
    enterButton->move(210,200);
    enterButton->setFont(ft);
    enterButton->setStyleSheet("background: rgb(255,255,255)");
    enterButton->setFixedSize(200,50);
    connect(enterButton,&QPushButton::clicked,this,[=](){
    emit enter();
        qDebug()<<"您已进入游戏";
    });

    connect(enterButton,&QPushButton::pressed,this,[=](){
        enterButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(enterButton,&QPushButton::released,this,[=](){
        enterButton->setStyleSheet("background: rgb(255,255,255)");
    });

    saveButton->setText("游戏存档");
    saveButton->move(210,275);
    saveButton->setFixedSize(200,50);
    saveButton->setFont(ft);
    saveButton->setStyleSheet("background: rgb(255,255,255)");

    connect(saveButton,&QPushButton::clicked,this,[=](){
    emit save();
        qDebug()<<"文档已保存";
    });

    connect(saveButton,&QPushButton::pressed,this,[=](){
        saveButton->setStyleSheet("background: rgb(	#191970)");
    });

    connect(saveButton,&QPushButton::released,this,[=](){
        saveButton->setStyleSheet("background: rgb(255,255,255)");
    });


    quitButton->setText("退出游戏");
    quitButton->move(210,350);
    quitButton->setFixedSize(200,50);
    quitButton->setFont(ft);
    quitButton->setStyleSheet("background: rgb(255,255,255)");

    connect(quitButton,&QPushButton::clicked,this,[=](){
    emit quit();
        qDebug()<<"您已退出游戏";
    });

    connect(quitButton,&QPushButton::pressed,this,[=](){
        quitButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(quitButton,&QPushButton::released,this,[=](){
        quitButton->setStyleSheet("background: rgb(255,255,255)");
    });
}

//槽函数
void startscene::enterGame()
{

}

void startscene::quitGame()
{
   QApplication::exit();
}

void startscene::saveGame()
{
//暂时不加
}
