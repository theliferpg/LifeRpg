#include "chooseVocationScence.h"

chooseVocationScence::chooseVocationScence(QWidget *parent)
{
    this->setParent(parent);
    this->resize(640,480);

    widgetsSet();
}

void chooseVocationScence::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,642,482,pixMap);
    QImage image;
    image.load(":/fightingBackground/Image/FightingBack/building2.png");
    painter.drawImage(0,0,image.scaled(this->width(),this->height()));
}

void chooseVocationScence::widgetsSet()
{
     QFont ft("Microsoft YaHei",20,75);

     QLabel *label=new QLabel(this);

    label->setText("职业选择");
    label->setFont(ft);
    label->setGeometry(rect().x()+210,rect().y()+10,200,50);

    label->setStyleSheet("font-size:50px;color:white");

    vocation1Button=new QPushButton(this);
    vocation2Button=new QPushButton(this);
    vocation3Button=new QPushButton(this);
    vocation4Button=new QPushButton(this);

    vocation1Button->setText("职业1");
    vocation1Button->move(50,100);
    vocation1Button->setFont(ft);
    vocation1Button->setStyleSheet("background: rgb(255,255,255)");
    //vocation1Button->setFixedSize(200,50);

    QIcon ico(":/Image/vocation/vocation1.png");
    vocation1Button->setIcon(ico);
    vocation1Button->setIconSize(QSize(100,100));
    vocation1Button->setFlat(true);

    connect(vocation1Button,&QPushButton::clicked,this,[=](){
        qDebug()<<"选择职业1";
        emit chooseVocation(1);
    });

    connect(vocation1Button,&QPushButton::pressed,this,[=](){
        vocation1Button->setStyleSheet("background: rgb(#191970)");
    });

    connect(vocation1Button,&QPushButton::released,this,[=](){
        vocation1Button->setStyleSheet("background: rgb(255,255,255)");
    });

    vocation2Button->setText("职业2");
    vocation2Button->move(300,100);
    //vocation2Button->setFixedSize(200,50);
    vocation2Button->setFont(ft);
    vocation2Button->setStyleSheet("background: rgb(255,255,255)");

    QIcon ico2(":/Image/vocation/2.png");
    vocation2Button->setIcon(ico2);
    vocation2Button->setIconSize(QSize(100,100));
    vocation2Button->setFlat(true);

    connect(vocation2Button,&QPushButton::clicked,this,[=](){

        qDebug()<<"选择职业2";
        emit chooseVocation(2);
    });

    connect(vocation2Button,&QPushButton::pressed,this,[=](){
        vocation2Button->setStyleSheet("background: rgb(	#191970)");
    });

    connect(vocation2Button,&QPushButton::released,this,[=](){
        vocation2Button->setStyleSheet("background: rgb(255,255,255)");
    });


    vocation3Button->setText("职业3");
    vocation3Button->move(50,300);
    //vocation3Button->setFixedSize(200,50);
    vocation3Button->setFont(ft);
    vocation3Button->setStyleSheet("background: rgb(255,255,255)");

    QIcon ico3(":/Image/vocation/3.png");
    vocation3Button->setIcon(ico3);
    vocation3Button->setIconSize(QSize(100,100));
    vocation3Button->setFlat(true);

    connect(vocation3Button,&QPushButton::clicked,this,[=](){

        qDebug()<<"选择职业3";
        emit chooseVocation(3);
    });

    connect(vocation3Button,&QPushButton::pressed,this,[=](){
        vocation3Button->setStyleSheet("background: rgb(#191970)");
    });

    connect(vocation3Button,&QPushButton::released,this,[=](){
        vocation3Button->setStyleSheet("background: rgb(255,255,255)");
    });

    vocation4Button->setText("职业4");
    vocation4Button->move(300,300);
    vocation4Button->setFont(ft);
    vocation4Button->setStyleSheet("background: rgb(255,255,255)");
    //vocation4Button->setFixedSize(200,50);

    QIcon ico4(":/Image/vocation/4.png");
    vocation4Button->setIcon(ico4);
    vocation4Button->setIconSize(QSize(100,100));
    vocation4Button->setFlat(true);

    connect(vocation4Button,&QPushButton::clicked,this,[=](){
        qDebug()<<"选择职业4";
        emit chooseVocation(4);
    });

    connect(vocation4Button,&QPushButton::pressed,this,[=](){
        vocation4Button->setStyleSheet("background: rgb(#191970)");
    });

    connect(vocation4Button,&QPushButton::released,this,[=](){
        vocation4Button->setStyleSheet("background: rgb(255,255,255)");
    });
}
