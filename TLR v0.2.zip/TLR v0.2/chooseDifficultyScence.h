#ifndef CHOOSEDIFFICULTYSCENCE_H
#define CHOOSEDIFFICULTYSCENCE_H
#include <QWidget>
#include<QPushButton>
#include<QPainter>
#include <QDebug>
#include "ui_mainwindow.h"
#include <QLabel>

class chooseDifficultyScence : public QWidget
{
    Q_OBJECT
public:
    explicit chooseDifficultyScence(QWidget *parent = nullptr);
    void widgetsSet();
    void paintEvent(QPaintEvent *event);

signals:
   void chooseDifficulty(int num);

public slots:

private:
    QPushButton *esayButton;
    QPushButton *commonButton;
    QPushButton *difficultButton;
    QPixmap pixMap;
};
#endif // CHOOSEDIFFICULTYSCENCE_H
