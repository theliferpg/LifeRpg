#ifndef START_H
#define START_H
#include <QWidget>
#include<QPushButton>
#include <QDebug>
#include<QPainter>
#include "ui_mainwindow.h"

class startscene : public QWidget
{
    Q_OBJECT
public:
    explicit startscene(QWidget *parent = nullptr);
    void widgetsSet();
    void paintEvent(QPaintEvent *event);


signals:
    void enter();
    void save();
    void quit();

public slots:
    void enterGame();
    void saveGame();
    void quitGame();
private:
    QPushButton *enterButton;
    QPushButton *saveButton;
    QPushButton *quitButton;
    QPixmap pixMap;
};

#endif // START_H
