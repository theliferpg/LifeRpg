#include"menuscene.h"
#include "player.h"
#include<QLabel>
extern Player player;
extern int map[20][15][10];

menuscene::menuscene(QWidget *parent)
{
    this->setParent(parent);
    this->resize(681,521);
    widgetSet();
}

void menuscene::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,640,480,pixMap);
    QImage image;
    image.load(":/startbacking/Image/startbacking/menu.png");
    painter.drawImage(0,0,image.scaled(this->width(),this->height()));

    button1->setText(QString::number(player.getHp()));
    button2->setText(QString::number(player.getAttack()));
    button3->setText(QString::number(player.getDefend()));
    button4->setText(QString::number(player.getExp()));
    button5->setText(QString::number(player.GetLevel()));
    button6->setText(QString::number(player.GetFloor()));
    button7->setText(QString::number(player.GetPosx())+","+QString::number(player.GetPosy()));
    button8->setText(QString::number(player.getMoney()));
    button9->setText(QString::number(player.GetVocation()));

}

void menuscene::widgetSet()
{
    QLabel *label1=new QLabel(this);
    QLabel *label2=new QLabel(this);
    QLabel *label3=new QLabel(this);
    QLabel *label4=new QLabel(this);
    QLabel *label5=new QLabel(this);
    QLabel *label6=new QLabel(this);
    QLabel *label7=new QLabel(this);
    QLabel *label8=new QLabel(this);
    QLabel *label9=new QLabel(this);

    label1->setText("生命值");
    label2->setText("攻击力");
    label3->setText("防御力");
    label4->setText("经验值");
    label5->setText("等级");
    label6->setText("所处位置");
    label7->setText("位置");
    label8->setText("金钱数量");
    label9->setText("职业");

    QFont ft("Microsoft YaHei",20,75);

    label1->setFont(ft);
    label2->setFont(ft);
    label3->setFont(ft);
    label4->setFont(ft);
    label5->setFont(ft);
    label6->setFont(ft);
    label7->setFont(ft);
    label8->setFont(ft);
    label9->setFont(ft);

    label1->setGeometry(rect().x()+50,rect().y()+25,200,50);
    label2->setGeometry(rect().x()+50,rect().y()+75,200,50);
    label3->setGeometry(rect().x()+50,rect().y()+125,200,50);
    label4->setGeometry(rect().x()+50,rect().y()+175,200,50);
    label5->setGeometry(rect().x()+50,rect().y()+225,200,50);
    label6->setGeometry(rect().x()+50,rect().y()+275,200,50);
    label7->setGeometry(rect().x()+50,rect().y()+325,200,50);
    label8->setGeometry(rect().x()+50,rect().y()+375,200,50);
    label9->setGeometry(rect().x()+50,rect().y()+425,200,50);

    button1=new QPushButton(this);
    button2=new QPushButton(this);
    button3=new QPushButton(this);
    button4=new QPushButton(this);
    button5=new QPushButton(this);
    button6=new QPushButton(this);
    button7=new QPushButton(this);
    button8=new QPushButton(this);
    button9=new QPushButton(this);

    button1->move(250,35);
    button2->move(250,85);
    button3->move(250,135);
    button4->move(250,185);
    button5->move(250,235);
    button6->move(250,285);
    button7->move(250,335);
    button8->move(250,385);
    button9->move(250,435);

    button1->setFixedSize(100,40);
    button2->setFixedSize(100,40);
    button3->setFixedSize(100,40);
    button4->setFixedSize(100,40);
    button5->setFixedSize(100,40);
    button6->setFixedSize(100,40);
    button7->setFixedSize(100,40);
    button8->setFixedSize(100,40);
    button9->setFixedSize(100,40);

    button1->setFont(ft);
    button2->setFont(ft);
    button3->setFont(ft);
    button4->setFont(ft);
    button5->setFont(ft);
    button6->setFont(ft);
    button7->setFont(ft);
    button8->setFont(ft);
    button9->setFont(ft);

    button1->setStyleSheet("background: rgb(255,255,255)");
    button2->setStyleSheet("background: rgb(255,255,255)");
    button3->setStyleSheet("background: rgb(255,255,255)");
    button4->setStyleSheet("background: rgb(255,255,255)");
    button5->setStyleSheet("background: rgb(255,255,255)");
    button6->setStyleSheet("background: rgb(255,255,255)");
    button7->setStyleSheet("background: rgb(255,255,255)");
    button8->setStyleSheet("background: rgb(255,255,255)");
    button9->setStyleSheet("background: rgb(255,255,255)");

    quitButton=new QPushButton(this);
    saveButton=new QPushButton(this);
    backButton=new QPushButton(this);

    saveButton->setText("游戏存档");
    saveButton->move(430,335);
    saveButton->setFixedSize(130,40);
    saveButton->setFont(ft);
    saveButton->setStyleSheet("background: rgb(255,255,255)");

    connect(saveButton,&QPushButton::clicked,this,[=](){
        //qDebug()<<"文档已保存";
        outputfile.open("C:\\Users\\xuehuijie\\Desktop\\TLR v0.2\\TLR v0.2\\keepfail.txt");
        if (!outputfile.fail())      //文件的写入
        {
            outputfile<<player.GetPosx()<<endl;
            outputfile<<player.GetPosy()<<endl;
            outputfile<<player.GetFloor()<<endl;
            outputfile<<player.getHp()<<endl;
            outputfile<<player.getExp()<<endl;
            outputfile<<player.getCrit()<<endl;
            outputfile<<player.getName().toStdString()<<endl;
            outputfile<<player.getMoney()<<endl;
            outputfile<<player.getSpeed()<<endl;
            outputfile<<player.getAttack()<<endl;
            outputfile<<player.getDefend()<<endl;
            outputfile<<player.GetLevel()<<endl;
            outputfile<<player.GetToward()<<endl;
            outputfile<<player.GetVocation()<<endl;

            qDebug()<<"writing file completed";
        }
        else
        {
            qDebug()<<"writing file failed";
        }
        outputfile.close();
    });

    connect(saveButton,&QPushButton::pressed,this,[=](){
        saveButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(saveButton,&QPushButton::released,this,[=](){
        saveButton->setStyleSheet("background: rgb(255,255,255)");
    });

    quitButton->setText("退出游戏");
    quitButton->move(430,435);
    quitButton->setFixedSize(130,40);
    quitButton->setFont(ft);
    quitButton->setStyleSheet("background: rgb(255,255,255)");

    connect(quitButton,&QPushButton::clicked,this,[=](){
        qDebug()<<"您已退出游戏";
        QApplication::exit();
    });

    connect(quitButton,&QPushButton::pressed,this,[=](){
        quitButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(quitButton,&QPushButton::released,this,[=](){
        quitButton->setStyleSheet("background: rgb(255,255,255)");
    });

    backButton->setText("返回游戏");
    backButton->move(430,385);
    backButton->setFixedSize(130,40);
    backButton->setFont(ft);
    backButton->setStyleSheet("background: rgb(255,255,255)");

    connect(backButton,&QPushButton::clicked,this,[=](){
        qDebug()<<"回到主界面";
        emit viewOut();
    });

    connect(backButton,&QPushButton::pressed,this,[=](){
        backButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(backButton,&QPushButton::released,this,[=](){
        backButton->setStyleSheet("background: rgb(255,255,255)");
    });

}

void menuscene::menuOut()
{

}

void menuscene::SetFoucs(){
    saveButton->setFocus();
}
