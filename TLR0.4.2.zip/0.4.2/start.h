#ifndef START_H
#define START_H
#include <QWidget>
#include<QPushButton>
#include <QDebug>
#include<QPainter>
#include "ui_mainwindow.h"
#include "music.h"

#include<QMessageBox>
#include<QSqlDatabase>
#include<QSqlQuery>
class startscene : public QWidget
{
    Q_OBJECT
public:
    explicit startscene(QWidget *parent = nullptr);
    void widgetsSet();
    void paintEvent(QPaintEvent *event);
    void stopMusic(){this->music->stop();};

signals:
    void enter();
    void reading();
    void quit();

public slots:
    void enterGame();
    void saveGame();
    void quitGame();
private:
    QPushButton *enterButton;
    QPushButton *saveButton;
    QPushButton *quitButton;
    QPixmap pixMap;
    Music* music;//****新添
};

#endif // START_H
