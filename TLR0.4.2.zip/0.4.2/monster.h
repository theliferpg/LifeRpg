#ifndef MONSTER_H
#define MONSTER_H

#include "Role.h"
#include <QString>
class Monster : public Role
{struct Difficulty{
        int hp; //生命值
        int attack; // 攻击力
        int defend; // 防御力
    };

public:
    Monster();
    ~Monster();
    //************
    void setSneer(QString sneer){this->sneer=sneer;};
    void setID(int ID){this->ID=ID;};
    void setSkillName(QString skill,int n,int target){this->skill[n]=skill;this->skillTarget[n]=target;};//********新添
    void setSkillFileName(QString skillFile,int n){this->skillFileName[n]=skillFile;};//********新添
    void setSkillDamage(int n,int value){this->skillDamage[n]=value;};//********新添

    QString getSneer(){return this->sneer;};
    int getID(){return this->ID;};
    QString getSkillName(int n){return this->skill[n];};//********新添
    QString getSkillFileName(int n){return this->skillFileName[n];};//********新添
    int getSkillTarget(int n){return this->skillTarget[n];};  //********新添
    int getSkillDamage(int n){return this->skillDamage[n];};  //********新添

    struct Difficulty difficult[3]={{0,0,0},
                                    {100,10,6},
                                    {200,20,12}};

    int action(int currentHP);//********怪物行为进阶

// 细节部分暂未想好，等实现了具体功能再看
private:
    int ID;
    QString sneer;
    QString skill[3];
    QString skillFileName[3];
    int skillTarget[3];
    int skillDamage[3];
};

#endif // MONSTER_H
