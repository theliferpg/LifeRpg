
#include <iostream>
#include <fstream>
#include <sstream>
#include <QPixmap>
#include <QDebug>
#include <QFile>
#include <QTextCodec>
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "player.h"
#include "monster.h"
#include "fightscene.h"
#include "menuscene.h"
#include "start.h"

using namespace std;

// Constants
const int kPixlen = 32;           // 图块像素大小
const int kOffsetX = 0;           // x轴偏移量
const int kOffsetY = 0;           // y轴偏移量
const int kDecimal = 10;          // 十进制系统设定

extern Player player;   // 玩家
extern int mmap[20][15][10]; // 地图，横坐标，纵坐标，地图编号
extern int mevents[20][15][10]; // 事件坐标

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    statusBar()->hide();

    initMap();
    initEvents();
    getMonstersFromFile();
    player.ChooseVocation(1);

    scene = new QGraphicsScene;
    view = new View(this);

    scene->setSceneRect(0,0,640,480); // 设置画布
    scene->addPixmap(QPixmap(":/map/Image/Map/test1.png"));
    view->setScene(scene);
    view->setMinimumSize(400,400);
    view->SetStatus("main");

    view->hide();

    //*******************************************************************************************************创建数据库
    QSqlDatabase db2 = QSqlDatabase::addDatabase("QSQLITE", "Players");
        db2.setDatabaseName(".//qtDb.db");
        if( !db2.open())
        {
            qDebug() << "无法建立数据库连接";
        }

            QSqlQuery query2(db2);
            bool success = query2.exec("create table PlayersInfo(level int,posx int,posy int,floor int,toward int,vocation int,"
                                       "need int,hp int,attack int,defend int,exp int,crit int,money int,speed int,name varchar)");
            if(success)
            {
                qDebug() << QObject::tr("数据库表创建成功！\n");
            }
            else
            {
                qDebug() << QObject::tr("数据库表创建失败！\n");
            }
    //********************************************************************************************************


    Start=new startscene(this);
    Start->show();

    Menuscene=new menuscene(this);
    Menuscene->hide();

    chooseDifficult=new chooseDifficultyScence(this);//难度选择界面***********************************
    chooseDifficult->hide();

    chooseVocation=new chooseVocationScence(this);//职业选择界面**************************************
    chooseVocation->hide();

    dialog = new Dialog(this);  // 初始对话框*****
    dialog->setParent(this);
    dialog->hide();

    connect(view, SIGNAL(change()), this, SLOT(slotDrawScene()));
    connect(view, SIGNAL(move(int, int)), this, SLOT(slotMovePlayerItem(int, int)));    // 移动连接槽
    connect(view, SIGNAL(fight(int)), this, SLOT(slotDrawFight(int)));                  // 显示战斗界面
    connect(view, SIGNAL(events(int, int)), this, SLOT(slotInteraction(int, int)));     // 对话框

    connect(Start,&startscene::enter,this,&MainWindow::slotChooseVocationOut);      //
    connect(chooseVocation,SIGNAL(chooseVocation(int)),this,SLOT(slotChooseDifficultOut(int)));

    connect(chooseDifficult,SIGNAL(chooseDifficulty(int)),this,SLOT(slotstartGame(int)));       //难度选择之后进入游戏

    connect(view,&View::MenuOut,this,&MainWindow::slotMenuOut);             // 召唤菜单栏
    connect(Menuscene,&menuscene::viewOut,this,&MainWindow::slotViewOut);   // 关闭菜单栏

    connect(Start,SIGNAL(reading()),this,SLOT(slotReadingStart()));

    AddPlayerItem(player.GetPosx(),player.GetPosy(),1);

    setCentralWidget(view);
    resize(642,482);
    setWindowTitle(tr("The Life RPG"));

}

MainWindow::~MainWindow()
{
    delete ui;
}

//新加的三个槽函数****************************************************
void MainWindow::slotstartGame(int num)
{
    view->SetStatus("main");
    slotDrawScene();
    view->setFocus();
    view->show();
    chooseDifficult->hide();
    numberOfDifficulty=num;


    //************************************************新加
    music=new Music("qrc:/music/music/mapSound .wav");
    music->setLoop();
    music->play();
}

void MainWindow::slotMenuOut()
{
    view->hide();
    view->SetStatus("menu");
    Menuscene->repaint();//为了更新属性的数据
    Menuscene->show();
    Menuscene->SetFoucs();
}

void MainWindow::slotViewOut()
{
    Menuscene->hide();
    view->SetStatus("main");
    view->show();
    view->setFocus();
}

void MainWindow::slotDrawScene() {          // 绘制图像
    if (view->GetStatus() != "main") return;
    scene->clear();
    scene->addPixmap(QPixmap(":/map/Image/Map/map" + QString::number(player.GetFloor()) + ".png"));
    AddPictureItem(0, 0, "tile");
    for (int i = 0; i < 20; i++)
        for (int j = 0; j < 15; j++)
            AddMapItem(i, j, mmap[i][j][player.GetFloor()]);
    AddPlayerItem(player.GetPosx(), player.GetPosy(), player.GetToward());
}

void MainWindow::slotChooseDifficultOut(int num)
{
    chooseVocation->hide();
    view->SetStatus("choose");
    chooseDifficult->show();
    numOfchooseVocation=num;
    player.ChooseVocation(num);
}

void MainWindow::slotChooseVocationOut()
{
    Start->hide();
    chooseVocation->show();
}

//********************************************************************************************新加的读档槽
void MainWindow::slotReadingStart()
{
    Start->stopMusic();
    Start->hide();
    slotDrawScene();
    view->show();
    //***music
    music=new Music("qrc:/music/music/mapSound .wav");
    music->setLoop();
    music->play();
}

void MainWindow::slotMovePlayerItem(int x, int y) {             // 移动玩家图像
    if (playerItem->zValue() == 0) {
        playerItem->moveBy(x*kPixlen, y*kPixlen);
        player.SetPosx(player.GetPosx() + x);
        player.SetPosy(player.GetPosy() + y);
        mmap[player.GetPosx()][player.GetPosy()][player.GetFloor()] = 0;
    }
}

void MainWindow::slotDrawFight(int num){
    view->hide();

    //fightScene=new FightScene(monsters[3]);
    fightScene=new FightScene(monsters[num - 77]);
    fightScene->setParent(this);
    connect(fightScene,&FightScene::backMap,this,&MainWindow::slotBackMapFromFight);  // 连接战斗槽
    fightScene->show();
    music->stop();                                 //*********新加的***
}

void MainWindow::slotBackMapFromFight(){                                     //****************我加的槽函数
    delete fightScene;
    view->setFocus();
    view->SetStatus("main");
    view->show();
    music->play();                          //*********新加的***
}

void MainWindow::slotInteraction(int x, int y){
    int tmp = mevents[x][y][player.GetFloor()];

    view->SetStatus("talk");

    dialog->setEvents(tmp);
    dialog->show();
    dialog->setFocus();
    dialog->setTextFocus();
    view->SetStatus("main");
}

void MainWindow::AddMapItem(int x, int y, int num) {            // 添加地图物块
    QGraphicsPixmapItem *item = scene->addPixmap(QPixmap(""));
    if(num == 77) item = scene->addPixmap(QPixmap(":/role/Image/Role/Ghost1.png"));
    else if(num >= 10) item = scene->addPixmap(QPixmap(":/role/Image/Role/" + QString::number(num) + ".png"));
    item->setPos(x*kPixlen, y*kPixlen);
}

void MainWindow::AddPictureItem(int x, int y, QString str) {    // 添加一些可能需要的背景
    QGraphicsPixmapItem *item = scene->addPixmap(QPixmap(":/images/" + str));
    //item->setFlag(QGraphicsItem::ItemIsMovable);
    item->setPos(x-kOffsetX,y-kOffsetY);
}

void MainWindow::AddPlayerItem(int x, int y, int toward) {      // 添加玩家物体
    QString str = ":/role/Image/Role/" + QString::number(toward) + ".png";
    playerItem = scene->addPixmap(QPixmap(str));
    playerItem->setPos(x*kPixlen-kOffsetX, y*kPixlen-kOffsetY);
}

void MainWindow::Clear() {              // 清空界面
    QList<QGraphicsItem*> listItem = scene->items();
    while(!listItem.empty()) {
        scene->removeItem(listItem.at(0));
        listItem.removeAt(0);
    }
}


void MainWindow::initMap(){
    QFile file(":/map/Set/map.txt");
    string line;
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        QTextStream in(&file);
        QString strLine;
        int k = 0, j = 0;
        while(!in.atEnd()){
            strLine = in.readLine();

            QStringList sections = strLine.split(" ");
//            qDebug() << sections;
            for(int i = 0; i < 20; i++)
                mmap[i][j][k] = sections.at(i).toInt();
            j++;
            if(j > 14){
                j = 0, k++;
            }
        }
    }else{
        qDebug() << "Error";
    }
    file.close();
}


void MainWindow::initEvents(){
    QFile file(":/map/Set/events.txt");
    string line;
    if(file.open(QIODevice::ReadOnly | QIODevice::Text)){
        QTextStream in(&file);
        QString strLine;
        int k = 0, j = 0;
        while(!in.atEnd()){
            strLine = in.readLine();

            QStringList sections = strLine.split(" ");
//            qDebug() << sections;
            for(int i = 0; i < 20; i++)
                mevents[i][j][k] = sections.at(i).toInt();
            j++;
            if(j > 14){
                j = 0, k++;
            }
        }
    }else{
        qDebug() << "Error";
    }
    file.close();
}



void MainWindow::getMonstersFromFile(){
    QFile file(":/monset/Set/monster0.txt");

    QString mname[7] = {"学走路", "中考", "高考", "失恋", "找工作", "实业", "养老"};
    QString msneer[7] = {"你不行", "你不行", "你不行", "你不行", "你不行", "你不行", "你不行"};
    QString mskill1[2]={"岩崩","爆炸"};
    QString mskill1File[2]={"Earth1","Fire2"};
    QString mskill2[2]={"岩突","日光束"};
    QString mskill2File[2]={"Earth2","Fire1"};
    QString mskill3[2]={"暗黑法球","混沌治疗"};
    QString mskill3File[2]={"Darkness1","Heal4"};

    if (file.open(QIODevice::ReadOnly | QIODevice::Text)) {
        for(int i=0;i<7;i++)
            monsters[i]=new Monster;

        QTextStream in(&file);
        QTextCodec *codec = QTextCodec::codecForName("GBK");
        in.setCodec(codec);
        QString strLine;

        int count = 0; bool flag = false;
        while(!in.atEnd()){
            strLine = codec->fromUnicode(in.readLine());

            QStringList sections = strLine.split(" ");

//            qDebug() << sections;

            if(!flag){
                flag = true;
                continue;
            }

            monsters[count]->setID(sections.at(0).toInt());
            monsters[count]->setName(mname[sections.at(1).toInt()]);
            monsters[count]->setHp(sections.at(2).toInt());
            monsters[count]->setAttack(sections.at(3).toInt());
            monsters[count]->setDefend(sections.at(4).toInt());
            monsters[count]->setMoney(sections.at(5).toInt());
            monsters[count]->setSpeed(sections.at(6).toInt());
            monsters[count]->setExp(sections.at(7).toInt());
            monsters[count]->setSneer(msneer[sections.at(8).toInt()]);
           //****新添  读取技能 及技能动画文件名
            monsters[count]->setSkillName(mskill1[sections.at(9).toInt()],0,sections.at(11).toInt());
            monsters[count]->setSkillFileName(mskill1File[sections.at(10).toInt()],0);
            monsters[count]->setSkillName(mskill2[sections.at(12).toInt()],1,sections.at(14).toInt());
            monsters[count]->setSkillFileName(mskill2File[sections.at(13).toInt()],1);
            monsters[count]->setSkillName(mskill3[sections.at(15).toInt()],2,sections.at(17).toInt());
            monsters[count]->setSkillFileName(mskill3File[sections.at(16).toInt()],2);
            monsters[count]->setSkillDamage(0,sections.at(18).toInt());
            monsters[count]->setSkillDamage(1,sections.at(19).toInt());
            monsters[count]->setSkillDamage(2,sections.at(20).toInt());

            qDebug()<<monsters[count]->getSkillDamage(0);
            count ++;
        }
    }else{
        qDebug() << "Error monster";
    }

    file.close();

}
