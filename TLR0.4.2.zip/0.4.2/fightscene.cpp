#include "fightscene.h"
#include <QLabel>
#include <QPushButton>
#include <QDebug>
#include <QPixmap>
#include <QPainter>
#include <QPoint>
#include <QKeyEvent>
#include <QTimer>
#include <QSound>
#include <QMediaPlayer>
#include <QLineEdit>

FightScene::FightScene(Monster*monster,QWidget *parent) : QWidget(parent)
{
    //获得怪物信息
    this->monster=monster;
    //设置基础属性
    this->resize(640,480);
    //this->setFocusPolicy(Qt::StrongFocus);//设置 焦点在战斗界面
    //设置QPixMap为底层画布
    pixMap=QPixmap(640,480);
    pixMap.fill(Qt::transparent);//设置透明  暂时没有背景图
    pixMap2=QPixmap(640,480);
    pixMap2.fill(Qt::transparent);//设置透明  暂时没有背景图
    pixMap3=QPixmap(640,480);
    pixMap3.fill(Qt::transparent);//设置透明  暂时没有背景图
    pixMap4=QPixmap(640,480);
    pixMap4.fill(Qt::transparent);//设置透明  暂时没有背景图
    pixMap5=QPixmap(640,480);
    pixMap5.fill(Qt::transparent);

    //设置主角and怪物HP
    this->currentRoleHP=player.getHp();
    this->currentMonsterHP=monster->getHp();
    this->currentRoleAttack=player.getAttack();
    this->currentRoleSpeed=player.getSpeed();
    //设置背景音乐
    battleBackSound=new Music("qrc:/music/music/battleBack.wav");//战斗
    battleBackSound->setLoop();
    battleBackSound->play();

    failMusic=new Music("qrc:/music/music/defeatFromOCT.wav");//失败
    failMusic->setLoop();
    connect(this,&FightScene::backMap,failMusic,[=](){
        failMusic->stop();
    });

    victoryMusic=new Music("qrc:/music/music/victoryFromOCT.wav");//胜利
    victoryMusic->setLoop();
    connect(this,&FightScene::backMap,victoryMusic,[=](){
        victoryMusic->stop();
    });


    //连接可攻击信号和攻击函数
    connect(this,&FightScene::roleFightSignal,this,&FightScene::roleAction);
    connect(this,&FightScene::BossFightSignal,this,&FightScene::BossAction);
    connect(this,&FightScene::roleFailSignal,this,&FightScene::FailView);
    connect(this,&FightScene::victorySignal,this,&FightScene::victoryView);
    connect(this,SIGNAL(damageSignal(int,int,int)),this,SLOT(damageText(int,int,int)));

    widgetsSet();
    //设置QTimer
    roleTimer=new QTimer(this);
    roleTimer->start(100);
    connect(roleTimer,&QTimer::timeout,this,[=](){
        BossX-=this->monster->getSpeed();
        roleX-=currentRoleSpeed;
        drawBasic1();
//        attack->setFocus();
        update();
    });

    //****测试物品
    player.addItems("小血瓶");
    player.addItems("小血瓶");player.addItems("攻击药水");
}

void FightScene::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    painter.drawPixmap(0,0,640,480,pixMap);
    if(pixMap2flag==1){
          painter.drawPixmap(0,0,640,480,pixMap2);
    }
    if(pixMap3flag==1){
          painter.drawPixmap(0,0,640,480,pixMap3);
    }
    if(pixMap4flag==1){
          painter.drawPixmap(0,0,640,480,pixMap4);
    }
    if(pixMap5flag==1){
          painter.drawPixmap(0,0,640,480,pixMap5);
    }
}

void FightScene::drawBasic1(){
    QPainter painter(&pixMap);
    painter.drawPixmap(0,0,640,480,pixMap);
    if(flag==0){
        pixMap.fill(Qt::transparent);
        QImage image;
        //绘制背景
        image.load(":/fightingBackground/Image/FightingBack/cave1.png");
        painter.drawImage(0,0,image.scaled(this->width(),this->height()));
        //绘制人物和boss
        image.load(":/role/Image/Role/2.png");
        painter.drawImage(450,300,image.scaled(80,80));
        QString Boss=":/Battlers/Image/Battlers/Battlers/7Boss/";
        Boss+=QString::number(this->monster->getID())+".png";
        image.load(Boss);
        painter.drawImage(20,100,image.scaled(350,280).mirrored(true,false));//镜面翻转


        //右上角绘制人物状态（HP之类的）
        image.load(":/role/Image/Role/1.png");
        painter.drawImage(460,10,image);
        QPen pen;
        pen.setWidth(20);
        pen.setColor(Qt::cyan);
        painter.setPen(pen);
        painter.drawLine(510,20,610,20);
        if(currentRoleHP*1.0/player.getHp()*100>=50)
            pen.setColor(Qt::green);
        else if(currentRoleHP*1.0/player.getHp()*100>=20)
            pen.setColor(Qt::yellow);
        else
            pen.setColor(Qt::red);
        painter.setPen(pen);
        if(currentRoleHP<0){
            currentRoleHP=0;//避免反向划线
        }
        painter.drawLine(510,20,510+currentRoleHP*1.0/player.getHp()*100,20);//血条长度=当前血量占总血量的多少*100像素
        pen.setColor(Qt::black);
        painter.setPen(pen);
        painter.drawText(QPoint(510,25),QString::number(currentRoleHP)+"/"+QString::number(player.getHp()));//血量的文字
        //绘制进度条
        pen.setColor(Qt::cyan);
        pen.setWidth(3);
        painter.setPen(pen);
        painter.drawLine(50,40,300,40);
        if(roleX<=30){
            //roleTimer->stop();
            emit roleFightSignal();//发送可攻击信号
            roleX=270;

        }
        if(BossX<=30){
            emit BossFightSignal();//发送可攻击信号
            BossX=270;
        }
        image.load(":/small/Image/smallIcon/skull.png");
        painter.drawImage(BossX,0,image.scaled(30,30));
        image.load(":/small/Image/smallIcon/1.png");
        painter.drawImage(roleX,45,image.scaled(30,30));
    }
}

//***新添  鼠标进入物品区域显示物品详细信息
void FightScene::mousePressEvent(QMouseEvent *ev){
    if(pixMap4flag!=0){
        int x=ev->x(),y=ev->y();
        qDebug()<<x<<"  "<<y;
        QPalette pa;
        pa.setColor(QPalette::WindowText,Qt::cyan);
        QFont ft;
        ft.setPointSize(14);
        QLabel* itemText;
        itemText=new QLabel("",this);

        if(x>=540&&x<=580&&y>=250){
            if(y<=290){
                itemText->setText("小血瓶\nHP+"+QString::number(player.GetObject("小血瓶").getValue()));
            }else if (y<=330) {
                itemText->setText("大血瓶\nHP+"+QString::number(player.GetObject("大血瓶").getValue()));
            }else if(y<=370){
                itemText->setText("速度药水\n速度+"+QString::number(player.GetObject("速度药水").getValue()));
            }
            else if(y<=410){
                itemText->setText("攻击药水\n攻击力+"+QString::number(player.GetObject("攻击药水").getValue()));
            }
            itemText->setPalette(pa);
            itemText->setFont(ft);
            itemText->move(500,200);
            itemText->show();
            QTimer* tempTimer=new QTimer(this);
            tempTimer->start(1200);
            connect(tempTimer,&QTimer::timeout,this,[=](){
                tempTimer->stop();
                itemText->hide();
            });
        }
    }else if(pixMap5flag!=0){

    }else{
        return;
    }
}

// 重写按键事件
void FightScene::keyPressEvent(QKeyEvent *event){
    if(pixMap4flag!=0){
        QPalette pa;
        QFont ft;
        ft.setPointSize(14);
        QLabel* itemText;
        itemText=new QLabel("",this);
        switch (event->key()) {
        case Qt::Key_1:
            qDebug()<<player.GetObject("小血瓶").getName()<<player.GetObject("小血瓶").getValue();
            if(player.GetObject("小血瓶").getNumber()>0){
                if(currentRoleHP+player.GetObject("小血瓶").getValue()>player.getHp()){
                    currentRoleHP=player.getHp();
                }else{
                    currentRoleHP+=player.GetObject("小血瓶").getValue();
                }
                player.deleteItems("小血瓶");
                roleTimer->start(100);
                pa.setColor(QPalette::WindowText,Qt::green);
                itemText->setText("HP+"+QString::number(player.GetObject("小血瓶").getValue()));
                pixMap4flag=0;
            }else{
                qDebug()<<"数量不够";
            }
            break;
        case Qt::Key_2:
            qDebug()<<player.GetObject("大血瓶").getName()<<player.GetObject("大血瓶").getValue();
            if(player.GetObject("大血瓶").getNumber()>0){

                if(currentRoleHP+player.GetObject("大血瓶").getValue()>player.getHp()){
                    currentRoleHP=player.getHp();
                }else{
                    currentRoleHP+=player.GetObject("大血瓶").getValue();
                }
                player.deleteItems("大血瓶");
                roleTimer->start(100);
                pa.setColor(QPalette::WindowText,Qt::green);
                itemText->setText("HP+"+QString::number(player.GetObject("大血瓶").getValue()));
                pixMap4flag=0;
            }else{
                qDebug()<<"数量不够";
            }
            break;
        case Qt::Key_3:
            qDebug()<<player.GetObject("速度药水").getName()<<player.GetObject("速度药水").getValue();
            if(player.GetObject("速度药水").getNumber()>0){
                currentRoleSpeed+=player.GetObject("速度药水").getValue();
                player.deleteItems("速度药水");
                roleTimer->start(100);
                pa.setColor(QPalette::WindowText,Qt::cyan);
                itemText->setText("速度+"+QString::number(player.GetObject("速度药水").getValue()));
                pixMap4flag=0;
            }else{
                qDebug()<<"数量不够";
            }
            break;
        case Qt::Key_4:
            qDebug()<<player.GetObject("攻击药水").getName()<<player.GetObject("攻击药水").getValue();
            if(player.GetObject("攻击药水").getNumber()>0){
                currentRoleAttack+=player.GetObject("攻击药水").getValue();
                player.deleteItems("攻击药水");
                roleTimer->start(100);
                pa.setColor(QPalette::WindowText,Qt::red);
                itemText->setText("攻击力+"+QString::number(player.GetObject("攻击药水").getValue()));
                pixMap4flag=0;
            }else{
                qDebug()<<"数量不够";
            }
            break;
        case Qt::Key_Z://返回
            pixMap4flag=0;
            attack->show();
            run->show();
            skills->show();
            objects->show();
            update();
        default:
            break;
        }
        itemText->setPalette(pa);
        itemText->setFont(ft);
        itemText->move(500,200);
        itemText->show();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            itemText->hide();
        });
    }else if(pixMap5flag != 0){
        QPalette pa;
        QFont ft;
        ft.setPointSize(14);
        QLabel* itemText;
        itemText=new QLabel("",this);
        switch(event->key()){
        case Qt::Key_1:
            if(player.getSkills()[0]->getisLearnt())
            {
                if(player.getSkills()[0]->getActive()){
                    if(player.getSkills()[0]->getAttribute() == "HP"){
                        if(currentRoleHP+player.getSkills()[0]->getValue()>player.getHp())
                            currentRoleHP=player.getHp();
                        else currentRoleHP+=player.getSkills()[0]->getValue();

                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::green);
                        itemText->setText("HP+"+QString::number(player.getSkills()[0]->getValue()));
                        pixMap5flag=0;
                    }else if(player.getSkills()[0]->getAttribute() == "Attack"){
                        int damage=currentRoleAttack+player.getSkills()[0]->getValue();
                        this->currentMonsterHP-=damage;

                        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;

                        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
                        temp->play();
                        emit damageSignal(damage,0,0);
                        pixMap5flag=0;
                        if(currentMonsterHP<=0){
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                            QTimer* tempTimer=new QTimer(this);
                            tempTimer->start(1200);
                            connect(tempTimer,&QTimer::timeout,this,[=](){
                                tempTimer->stop();
                                emit victorySignal();
                            });
                        }else{
                            roleTimer->start(100);
                            this->setFocus();
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                        }
                    }else if(player.getSkills()[0]->getAttribute() == "Speed"){
                        currentRoleSpeed+=player.GetObject("速度药水").getValue();
                        player.deleteItems("速度药水");
                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::cyan);
                        itemText->setText("速度+"+QString::number(player.getSkills()[0]->getValue()));
                        pixMap5flag=0;
                    }
                }else{
                    qDebug() << "被动技能无法使用";
                }
            }else{
                qDebug() << "该技能还未学习";
            }
            break;
        case Qt::Key_2:
            if(player.getSkills()[1]->getisLearnt())
            {
                if(player.getSkills()[1]->getActive()){
                    if(player.getSkills()[1]->getAttribute() == "HP"){
                        if(currentRoleHP+player.getSkills()[1]->getValue()>player.getHp())
                            currentRoleHP=player.getHp();
                        else currentRoleHP+=player.getSkills()[1]->getValue();

                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::green);
                        itemText->setText("HP+"+QString::number(player.getSkills()[1]->getValue()));
                        pixMap5flag=0;
                    }else if(player.getSkills()[1]->getAttribute() == "Attack"){
                        int damage=currentRoleAttack+player.getSkills()[1]->getValue();
                        this->currentMonsterHP-=damage;

                        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;

                        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
                        temp->play();
                        emit damageSignal(damage,0,0);
                        pixMap5flag=0;
                        if(currentMonsterHP<=0){
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                            QTimer* tempTimer=new QTimer(this);
                            tempTimer->start(1200);
                            connect(tempTimer,&QTimer::timeout,this,[=](){
                                tempTimer->stop();
                                emit victorySignal();
                            });
                        }else{
                            roleTimer->start(100);
                            this->setFocus();
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                        }
                    }else if(player.getSkills()[1]->getAttribute() == "Speed"){
                        currentRoleSpeed+=player.GetObject("速度药水").getValue();
                        player.deleteItems("速度药水");
                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::cyan);
                        itemText->setText("速度+"+QString::number(player.getSkills()[1]->getValue()));
                        pixMap5flag=0;
                    }
                }else{
                    qDebug() << "被动技能无法使用";
                }
            }else{
                qDebug() << "该技能还未学习";
            }
            break;
        case Qt::Key_3:
            if(player.getSkills()[2]->getisLearnt())
            {
                if(player.getSkills()[2]->getActive()){
                    if(player.getSkills()[2]->getAttribute() == "HP"){
                        if(currentRoleHP+player.getSkills()[2]->getValue()>player.getHp())
                            currentRoleHP=player.getHp();
                        else currentRoleHP+=player.getSkills()[2]->getValue();

                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::green);
                        itemText->setText("HP+"+QString::number(player.getSkills()[2]->getValue()));
                        pixMap5flag=0;
                    }else if(player.getSkills()[2]->getAttribute() == "Attack"){
                        int damage=currentRoleAttack+player.getSkills()[2]->getValue();
                        this->currentMonsterHP-=damage;

                        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;

                        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
                        temp->play();
                        emit damageSignal(damage,0,0);
                        pixMap5flag=0;
                        if(currentMonsterHP<=0){
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                            QTimer* tempTimer=new QTimer(this);
                            tempTimer->start(1200);
                            connect(tempTimer,&QTimer::timeout,this,[=](){
                                tempTimer->stop();
                                emit victorySignal();
                            });
                        }else{
                            roleTimer->start(100);
                            this->setFocus();
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                        }
                    }else if(player.getSkills()[2]->getAttribute() == "Speed"){
                        currentRoleSpeed+=player.GetObject("速度药水").getValue();
                        player.deleteItems("速度药水");
                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::cyan);
                        itemText->setText("速度+"+QString::number(player.getSkills()[2]->getValue()));
                        pixMap5flag=0;
                    }
                }else{
                    qDebug() << "被动技能无法使用";
                }
            }else{
                qDebug() << "该技能还未学习";
            }
            break;
        case Qt::Key_4:
            if(player.getSkills()[3]->getisLearnt())
            {
                if(player.getSkills()[3]->getActive()){
                    if(player.getSkills()[3]->getAttribute() == "HP"){
                        if(currentRoleHP+player.getSkills()[3]->getValue()>player.getHp())
                            currentRoleHP=player.getHp();
                        else currentRoleHP+=player.getSkills()[3]->getValue();

                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::green);
                        itemText->setText("HP+"+QString::number(player.getSkills()[3]->getValue()));
                        pixMap5flag=0;
                    }else if(player.getSkills()[3]->getAttribute() == "Attack"){
                        int damage=currentRoleAttack+player.getSkills()[3]->getValue();
                        this->currentMonsterHP-=damage;

                        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;

                        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
                        temp->play();
                        emit damageSignal(damage,0,0);
                        pixMap5flag=0;
                        if(currentMonsterHP<=0){
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                            QTimer* tempTimer=new QTimer(this);
                            tempTimer->start(1200);
                            connect(tempTimer,&QTimer::timeout,this,[=](){
                                tempTimer->stop();
                                emit victorySignal();
                            });
                        }else{
                            roleTimer->start(100);
                            this->setFocus();
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                        }
                    }else if(player.getSkills()[3]->getAttribute() == "Speed"){
                        currentRoleSpeed+=player.GetObject("速度药水").getValue();
                        player.deleteItems("速度药水");
                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::cyan);
                        itemText->setText("速度+"+QString::number(player.getSkills()[3]->getValue()));
                        pixMap5flag=0;
                    }
                }else{
                    qDebug() << "被动技能无法使用";
                }
            }else{
                qDebug() << "该技能还未学习";
            }
            break;
        case Qt::Key_5:
            if(player.getSkills()[4]->getisLearnt())
            {
                if(player.getSkills()[4]->getActive()){
                    if(player.getSkills()[4]->getAttribute() == "HP"){
                        if(currentRoleHP+player.getSkills()[4]->getValue()>player.getHp())
                            currentRoleHP=player.getHp();
                        else currentRoleHP+=player.getSkills()[4]->getValue();

                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::green);
                        itemText->setText("HP+"+QString::number(player.getSkills()[4]->getValue()));
                        pixMap5flag=0;
                    }else if(player.getSkills()[4]->getAttribute() == "Attack"){
                        int damage=currentRoleAttack+player.getSkills()[4]->getValue();
                        this->currentMonsterHP-=damage;

                        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;

                        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
                        temp->play();
                        emit damageSignal(damage,0,0);
                        pixMap5flag=0;
                        if(currentMonsterHP<=0){
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                            QTimer* tempTimer=new QTimer(this);
                            tempTimer->start(1200);
                            connect(tempTimer,&QTimer::timeout,this,[=](){
                                tempTimer->stop();
                                emit victorySignal();
                            });
                        }else{
                            roleTimer->start(100);
                            this->setFocus();
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                        }
                    }else if(player.getSkills()[4]->getAttribute() == "Speed"){
                        currentRoleSpeed+=player.GetObject("速度药水").getValue();
                        player.deleteItems("速度药水");
                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::cyan);
                        itemText->setText("速度+"+QString::number(player.getSkills()[4]->getValue()));
                        pixMap5flag=0;
                    }
                }else{
                    qDebug() << "被动技能无法使用";
                }
            }else{
                qDebug() << "该技能还未学习";
            }
            break;
        case Qt::Key_6:
            if(player.getSkills()[5]->getisLearnt())
            {
                if(player.getSkills()[5]->getActive()){
                    if(player.getSkills()[5]->getAttribute() == "HP"){
                        if(currentRoleHP+player.getSkills()[5]->getValue()>player.getHp())
                            currentRoleHP=player.getHp();
                        else currentRoleHP+=player.getSkills()[5]->getValue();

                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::green);
                        itemText->setText("HP+"+QString::number(player.getSkills()[5]->getValue()));
                        pixMap5flag=0;
                    }else if(player.getSkills()[5]->getAttribute() == "Attack"){
                        int damage=currentRoleAttack+player.getSkills()[1]->getValue();
                        this->currentMonsterHP-=damage;

                        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;

                        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
                        temp->play();
                        emit damageSignal(damage,0,0);
                        pixMap5flag=0;
                        if(currentMonsterHP<=0){
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                            QTimer* tempTimer=new QTimer(this);
                            tempTimer->start(1200);
                            connect(tempTimer,&QTimer::timeout,this,[=](){
                                tempTimer->stop();
                                emit victorySignal();
                            });
                        }else{
                            roleTimer->start(100);
                            this->setFocus();
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                        }
                    }else if(player.getSkills()[5]->getAttribute() == "Speed"){
                        currentRoleSpeed+=player.GetObject("速度药水").getValue();
                        player.deleteItems("速度药水");
                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::cyan);
                        itemText->setText("速度+"+QString::number(player.getSkills()[5]->getValue()));
                        pixMap5flag=0;
                    }
                }else{
                    qDebug() << "被动技能无法使用";
                }
            }else{
                qDebug() << "该技能还未学习";
            }
            break;
        case Qt::Key_7:
            if(player.getSkills()[6]->getisLearnt())
            {
                if(player.getSkills()[6]->getActive()){
                    if(player.getSkills()[6]->getAttribute() == "HP"){
                        if(currentRoleHP+player.getSkills()[6]->getValue()>player.getHp())
                            currentRoleHP=player.getHp();
                        else currentRoleHP+=player.getSkills()[6]->getValue();

                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::green);
                        itemText->setText("HP+"+QString::number(player.getSkills()[6]->getValue()));
                        pixMap5flag=0;
                    }else if(player.getSkills()[6]->getAttribute() == "Attack"){
                        int damage=currentRoleAttack+player.getSkills()[1]->getValue();
                        this->currentMonsterHP-=damage;

                        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;

                        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
                        temp->play();
                        emit damageSignal(damage,0,0);
                        pixMap5flag=0;
                        if(currentMonsterHP<=0){
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                            QTimer* tempTimer=new QTimer(this);
                            tempTimer->start(1200);
                            connect(tempTimer,&QTimer::timeout,this,[=](){
                                tempTimer->stop();
                                emit victorySignal();
                            });
                        }else{
                            roleTimer->start(100);
                            this->setFocus();
                            run->hide();
                            attack->hide();
                            skills->hide();
                            objects->hide();
                        }
                    }else if(player.getSkills()[6]->getAttribute() == "Speed"){
                        currentRoleSpeed+=player.GetObject("速度药水").getValue();
                        player.deleteItems("速度药水");
                        roleTimer->start(100);
                        pa.setColor(QPalette::WindowText,Qt::cyan);
                        itemText->setText("速度+"+QString::number(player.getSkills()[6]->getValue()));
                        pixMap5flag=0;
                    }
                }else{
                    qDebug() << "被动技能无法使用";
                }
            }else{
                qDebug() << "该技能还未学习";
            }
            break;
        case Qt::Key_Z:
            pixMap5flag=0;
            attack->show();
            run->show();
            skills->show();
            objects->show();
            update();
            break;
        default:
            break;
        }
        itemText->setPalette(pa);
        itemText->setFont(ft);
        itemText->move(500,200);
        itemText->show();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            itemText->hide();
        });
    }else{
        return;
    }
}

//控件设置
void FightScene::widgetsSet(){
    attack=new QPushButton(this);
    objects=new QPushButton(this);
    skills=new QPushButton(this);
    run=new QPushButton(this);
    back=new QPushButton(this);

    attack->hide();//初始设为不可见
    run->hide();
    back->hide();
    skills->hide();
    objects->hide();//****
    connect(this,&FightScene::roleFightSignal,this,[=](){
        run->show();
        attack->show();
        skills->show();
        objects->show();
    });
    //攻击按键设置
    attack->setText("攻击");
    attack->move(540,250);
    connect(attack,&QPushButton::clicked,this,[=](){
        int damage=currentRoleAttack;
        this->currentMonsterHP-=damage;
        //this->currentMonsterHP-=player.getAttack()*1.0/(1+0.05*monster->getDefend());
        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;
        //****新添
        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
        temp->play();
        emit damageSignal(damage,0,0);


        if(currentMonsterHP<=0){
            run->hide();
            attack->hide();
            skills->hide();
            objects->hide();
            QTimer* tempTimer=new QTimer(this);
            tempTimer->start(1200);
            connect(tempTimer,&QTimer::timeout,this,[=](){
                tempTimer->stop();
                emit victorySignal();
            });
        }else{
            roleTimer->start(100);
            this->setFocus();
            run->hide();
            attack->hide();
            skills->hide();
            objects->hide();
        }
    });
    //物品按键设置
    objects->setText("物品");
    objects->move(540,280);
    connect(objects,&QPushButton::clicked,this,[=](){
        qDebug()<<"你打开了物品栏";
        pixMap4flag=1;
        drawItems();
        run->hide();
        attack->hide();
        skills->hide();
        objects->hide();

    });
    // 技能按键设置
    skills->setText("技能");
    skills->move(540, 310);
    connect(skills, &QPushButton::clicked, this,[=](){
        qDebug()<<"你打开了技能栏";
        pixMap5flag=1;
        drawSkills();
        run->hide();
        attack->hide();
        skills->hide();
        objects->hide();
    });
    //逃跑按键设置
    run->setText("逃跑");
    run->move(540,340);
    connect(run,&QPushButton::clicked,this,[=](){
        qDebug()<<"你逃跑了";
        run->hide();
        attack->hide();
        skills->hide();
        objects->hide();
        roleTimer->stop();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            emit roleFailSignal();

        });
    });
    //返回地图按键
    back->setText("返回地图");
    back->move(this->width()/2-50,this->height()-50);
    connect(back,&QPushButton::clicked,this,[=](){
        this->hide();
        emit backMap();

    });
}
//****新添  绘制物品栏
void FightScene::drawItems(){
    QPainter painter(&pixMap4);
    pixMap4.fill(Qt::transparent);
    QImage image;
    image.load(":/object/Image/Object/blood_small.bmp");
    painter.drawImage(QPoint(540,250),image.scaled(40,40));
    image.load(":/object/Image/Object/blood_big.bmp");
    painter.drawImage(QPoint(540,290),image.scaled(40,40));
    image.load(":/object/Image/Object/speed_up.BMP");
    painter.drawImage(QPoint(540,330),image.scaled(40,40));
    image.load(":/object/Image/Object/attack_up.bmp");
    painter.drawImage(QPoint(540,370),image.scaled(40,40));
    QPen pen;
    pen.setColor(Qt::cyan);
    //pen.setWidth(3);
    painter.setPen(pen);
    painter.drawText(QPoint(585,280)," X "+QString::number(player.GetObject("小血瓶").getNumber()));
    painter.drawText(QPoint(585,320)," X "+QString::number(player.GetObject("大血瓶").getNumber()));
    painter.drawText(QPoint(585,360)," X "+QString::number(player.GetObject("速度药水").getNumber()));
    painter.drawText(QPoint(585,400)," X "+QString::number(player.GetObject("攻击药水").getNumber()));
    update();
}
//***新添 绘制技能栏
void FightScene::drawSkills(){
    QPainter painter(&pixMap5);
    pixMap5.fill(Qt::transparent);
    QImage image;
    image.load(":/skill/Image/Skill/1.bmp");
    painter.drawImage(QPoint(540,200),image.scaled(30,30));
    image.load(":/skill/Image/Skill/2.bmp");
    painter.drawImage(QPoint(540,230),image.scaled(30,30));
    image.load(":/skill/Image/Skill/3.bmp");
    painter.drawImage(QPoint(540,260),image.scaled(30,30));
    image.load(":/skill/Image/Skill/4.bmp");
    painter.drawImage(QPoint(540,290),image.scaled(30,30));
    image.load(":/skill/Image/Skill/5.bmp");
    painter.drawImage(QPoint(540,320),image.scaled(30,30));
    image.load(":/skill/Image/Skill/6.bmp");
    painter.drawImage(QPoint(540,350),image.scaled(30,30));
    image.load(":/skill/Image/Skill/7.bmp");
    painter.drawImage(QPoint(540,380),image.scaled(30,30));
    update();
}
// 增加伤害的显示
void FightScene::damageText(int value,int who,int color){//value 代表伤害值  who代表受伤的角色  0代表怪物 1代表玩家
    QPalette pa;
    if(color==0)
        pa.setColor(QPalette::WindowText,Qt::red);
    else
        pa.setColor(QPalette::WindowText,Qt::green);
    QFont ft;
    ft.setPointSize(14);
    QLabel* monsterDamageText;
    QLabel* roleDamageText;
    if(who==0){
        if(color==0)
            monsterDamageText=new QLabel("-"+QString::number(value),this);
        if(color==1)
            monsterDamageText=new QLabel("+"+QString::number(value),this);
        monsterDamageText->setPalette(pa);
        monsterDamageText->setFont(ft);
        monsterDamageText->move(200,380);
        monsterDamageText->show();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            monsterDamageText->hide();
        });
    }else if(who==1){
        if(color==0)
            roleDamageText=new QLabel("-"+QString::number(value),this);
        if(color==1)
            roleDamageText=new QLabel("+"+QString::number(value),this);
        roleDamageText->setPalette(pa);
        roleDamageText->setFont(ft);
        roleDamageText->move(450,380);
        roleDamageText->show();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            roleDamageText->hide();
        });
    }



}
//绘制怪物文本和技能特效
void FightScene::drawMonsterAction(QString text,QString skill,int object){
    //设置对象
    int x=0,y=0;
    if(object==1){      //代表对玩家释放
        x=400,y=250;
    }
    else{               //代表对自己释放
         x=100,y=130;
    }

    //文字
    QPainter painter(&pixMap2);
    pixMap2.fill(Qt::transparent);
    pixMap2flag=1;
    QTimer* tempTimer=new QTimer(this);
    tempTimer->start(1200);
    connect(tempTimer,&QTimer::timeout,this,[=](){
        tempTimer->stop();
        pixMap2flag=0;
    });
    QPen pen;
    pen.setColor(Qt::red);
    painter.setPen(pen);
    painter.setFont(QFont("Microsoft YaHei",20,75));
    painter.drawText(QPoint(60,450),text);
    //动画
    if(skill!="null"){
        //动画
        QPainter painter2(&pixMap3);
        pixMap3.fill(Qt::transparent);
        pixMap3flag=1;

        int i=0;
        QImage image[10];
        for(int j=0;j<10;++j){
            image[j].load(":/animation/Image/Animation/"+skill+"_"+QString::number(0)+QString::number(j+1)+".png");//加载图片
        }

        painter2.drawImage(x,y,image[0]);
        QTimer* tempTimer2=new QTimer(this);
        tempTimer2->start(150);
        connect(tempTimer2,&QTimer::timeout,this,[=](){
            static int i=1;
            QPainter painter2(&pixMap3);
            pixMap3.fill(Qt::transparent);
            if(i<10){
                qDebug()<<i;
                painter2.drawImage(x,y,image[i++]);

            }else{
                tempTimer2->stop();
                i=1;
                pixMap3flag=0;
            }
            update();
        });

    }
}

//以下都是槽函数
void FightScene::roleAction(){

    roleTimer->stop();
    attack->setFocus();//每次重新设置攻击键为焦点
}

void FightScene::BossAction(){

    Music*temp=new Music("qrc:/music/music/monsterAttack.wav");
    temp->play();

    int monsterAction=monster->action(currentMonsterHP);//****1代表嘲讽 2代表普通攻击 3代表技能1 4代表必杀技
    if(monsterAction==1){
        //动画
        drawMonsterAction(monster->getName()+"嘲讽道："+monster->getSneer(),"null",1);
    }else if(monsterAction==2){
        //攻击伤害
        int damage=monster->getAttack();
        currentRoleHP-=damage;
        emit damageSignal(damage,1,0);
         //动画
        drawMonsterAction(monster->getName()+"使用了普通攻击","null",1);
    }
    else if(monsterAction==3){
        //攻击伤害
        int damage=monster->getAttack()+monster->getSkillDamage(0);
        currentRoleHP-=damage;
        emit damageSignal(damage,1,0);
        //动画
        drawMonsterAction(monster->getName()+"使用了"+monster->getSkillName(0),monster->getSkillFileName(0),monster->getSkillTarget(0));
    }
    else if(monsterAction==4){
        //攻击
        int damage=monster->getAttack()+monster->getSkillDamage(1);
        currentRoleHP-=damage;
        emit damageSignal(damage,1,0);
        //动画
        drawMonsterAction(monster->getName()+"使用了"+monster->getSkillName(1),monster->getSkillFileName(1),monster->getSkillTarget(1));
    }
    else {
        //攻击
        int damage=monster->getAttack()+monster->getSkillDamage(2);
        if(monster->getSkillTarget(2)==1){
            currentRoleHP-=damage;
            emit damageSignal(damage,1,0);
            //动画
            drawMonsterAction(monster->getName()+"使用了必杀技"+monster->getSkillName(2),monster->getSkillFileName(2),monster->getSkillTarget(2));
        }else{
            currentMonsterHP+=damage;
            emit damageSignal(damage,0,1);
            //动画
            drawMonsterAction(monster->getName()+"对自己使用了"+monster->getSkillName(2),monster->getSkillFileName(2),monster->getSkillTarget(2));
        }

    }
    update();
    //判断角色死亡
    if(currentRoleHP<=0){
        roleTimer->stop();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(2000);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            emit roleFailSignal();
            roleTimer->stop();
        });
    }


}

void FightScene::FailView(){
    battleBackSound->stop();
    failMusic->play();

    QImage image;
    image.load(":/fightingBackground/Image/GameOver/gameover.png");
    QPainter painter(&pixMap);
    painter.drawImage(QPoint(0,0),image.scaled(this->width(),this->height()));
    flag=1;//战斗结束
    update();
    back->show();
    back->setFocus();
    attack->hide();
    skills->hide();
    objects->hide();
    run->hide();

}
//胜利结算界面  暂时先这样
void FightScene::victoryView(){
    battleBackSound->stop();
    victoryMusic->play();

    QImage image;
    image.load(":/fightingBackground/Image/GameOver/victory.png");
    QPainter painter(&pixMap);
    pixMap.fill(Qt::transparent);
    QPen pen;
    pen.setColor(Qt::cyan);
    painter.setPen(pen);
    QBrush brush(Qt::cyan);
    brush.setStyle(Qt::Dense3Pattern);
    painter.setBrush(brush);
    painter.drawRect(QRect(0,0,this->width(),this->height()));
    painter.drawImage(QPoint(0,0),image);
    flag=1;//战斗结束
    update();
    back->show();
    back->setFocus();
    attack->hide();
    skills->hide();
    objects->hide();
    run->hide();
    player.LevelUp();
}
