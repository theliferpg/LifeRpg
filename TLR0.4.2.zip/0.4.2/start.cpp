#include"start.h"
#include "player.h"

extern Player player;
extern int map[20][15][10];
//构造函数
startscene::startscene(QWidget *parent)
{
     this->setParent(parent);
     this->resize(640,480);
     connect(this, SIGNAL(enter()), this, SLOT(enterGame()));
//     connect(this, SIGNAL(save()), this, SLOT(saveGame()));
     connect(this, SIGNAL(quit()), this, SLOT(quitGame()));

     widgetsSet();

     //********* 新添
     music=new Music("qrc:/music/music/startSceneSound .wav");
     music->setLoop();
     music->play();
}

void startscene::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    painter.drawPixmap(0,0,642,482,pixMap);
    QImage image;
    image.load(":/startbacking/Image/startbacking/start.png");
    painter.drawImage(0,0,image.scaled(this->width(),this->height()));
}

//设置控件
void startscene::widgetsSet()
{
    enterButton=new QPushButton(this);
    saveButton=new QPushButton(this);
    quitButton=new QPushButton(this);

    QFont ft("Microsoft YaHei",20,75);

    enterButton->setText("进入游戏");
    enterButton->move(210,200);
    enterButton->setFont(ft);
    enterButton->setStyleSheet("background: rgb(255,255,255)");
    enterButton->setFixedSize(200,50);
    connect(enterButton,&QPushButton::clicked,this,[=](){
    emit enter();
        qDebug()<<"您已进入游戏";
    });

    connect(enterButton,&QPushButton::pressed,this,[=](){
        enterButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(enterButton,&QPushButton::released,this,[=](){
        enterButton->setStyleSheet("background: rgb(255,255,255)");
    });

    saveButton->setText("游戏读档");
    saveButton->move(210,275);
    saveButton->setFixedSize(200,50);
    saveButton->setFont(ft);
    saveButton->setStyleSheet("background: rgb(255,255,255)");

    connect(saveButton,&QPushButton::clicked,this,[=](){

        qDebug()<<"读档";//*****************************************************************************修改信号为reading，读取数据库
        QSqlDatabase db = QSqlDatabase::database("Players"); //建立数据库连接
            QSqlQuery query(db);
            query.exec("select * from PlayersInfo");
            int level;
            int posX;
            int posY;
            int floor;
            int toward;
            int vocation;
            int need;
            int hp;
            int attack;
            int defend;
            int exp;
            int crit;
            int money;
            int speed;
            QString name;
            while(query.next())
            {
                level=query.value(0).toInt();
                qDebug() << query.value(0).toInt() << " ";

                posX=query.value(1).toInt();
                qDebug() << query.value(1).toInt() << " ";

                posY=query.value(2).toInt();
                qDebug() << query.value(2).toInt() << " ";

                floor=query.value(3).toInt();
                qDebug() << query.value(3).toInt() << " ";

                toward=query.value(4).toInt();
                qDebug() << query.value(4).toInt() << " ";

                vocation=query.value(5).toInt();
                qDebug() << query.value(5).toInt() << " ";

                need=query.value(6).toInt();
                qDebug() << query.value(6).toInt() << " ";

                hp=query.value(7).toInt();
                qDebug() << query.value(7).toInt() << " ";

                attack=query.value(8).toInt();
                qDebug() << query.value(8).toInt() << " ";

                defend=query.value(9).toInt();
                qDebug() << query.value(9).toInt() << " ";

                exp=query.value(10).toInt();
                qDebug() << query.value(10).toInt() << " ";

                crit=query.value(11).toInt();
                qDebug() << query.value(11).toInt() << " ";

                money=query.value(12).toInt();
                qDebug() << query.value(12).toInt() << " ";

                speed=query.value(13).toInt();
                qDebug() << query.value(13).toInt() << " ";

                name=query.value(14).toString();
                qDebug() << query.value(14).toString() << " ";

                qDebug() << "\n";
            }
            player.SetLevel(level);
            player.SetPosx(posX);
            player.SetPosy(posY);
            player.SetFloor(floor);
            player.SetToward(toward);
            player.SetVocation(vocation);
            player.setHp(hp);
            player.setAttack(attack);
            player.setDefend(defend);
            player.setExp(exp);
            player.setCrit(crit);
            player.setMoney(money);
            player.setSpeed(speed);
            player.setName(name);
            //player.ChooseVocation(vocation);
         emit reading();
    });

    connect(saveButton,&QPushButton::pressed,this,[=](){
        saveButton->setStyleSheet("background: rgb(	#191970)");
    });

    connect(saveButton,&QPushButton::released,this,[=](){
        saveButton->setStyleSheet("background: rgb(255,255,255)");
    });


    quitButton->setText("退出游戏");
    quitButton->move(210,350);
    quitButton->setFixedSize(200,50);
    quitButton->setFont(ft);
    quitButton->setStyleSheet("background: rgb(255,255,255)");

    connect(quitButton,&QPushButton::clicked,this,[=](){
    emit quit();
        qDebug()<<"您已退出游戏";
    });

    connect(quitButton,&QPushButton::pressed,this,[=](){
        quitButton->setStyleSheet("background: rgb(#191970)");
    });

    connect(quitButton,&QPushButton::released,this,[=](){
        quitButton->setStyleSheet("background: rgb(255,255,255)");
    });
}

//槽函数
void startscene::enterGame()
{
    music->stop();//******新添  关闭音乐
}

void startscene::quitGame()
{
   QApplication::exit();
}

void startscene::saveGame()
{
//暂时不加
}
