#ifndef MENUSCENE_H
#define MENUSCENE_H
#include<QWidget>
#include<QPushButton>
#include<QDebug>
#include "ui_mainwindow.h"
#include <QPainter>
#include <QLabel>
#include <QTextEdit>
#include <QSqlQuery>
#include <QSqlError>
class menuscene : public QWidget
{
    Q_OBJECT
public:
    explicit menuscene(QWidget *parent = nullptr);
    void widgetSet();
    void paintEvent(QPaintEvent *event);
    void SetFoucs();
    void musicButtonSet();//*****新加

signals:
    void viewOut();
    void musicSignal(int);//*****新加

public slots:
    void menuOut();

private:
    QPushButton *saveButton;
    QPushButton *quitButton;
    QPushButton *backButton;
    QPixmap pixMap;

    QPushButton *button1;
    QPushButton *button2;
    QPushButton *button3;
    QPushButton *button4;
    QPushButton *button5;
    QPushButton *button6;
    QPushButton *button7;
    QPushButton *button8;
    QPushButton *button9;

    QPushButton* musicSwitch;//***新添
    QTextEdit *skill;
};

#endif // MENUSCENE_H
