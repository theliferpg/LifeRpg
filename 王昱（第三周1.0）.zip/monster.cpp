#include "monster.h"
#include <QDebug>
Monster::Monster()
{

}
Monster::~Monster(){

}
//********怪物行为进阶
int Monster::action(int currentHP){
    double ratio=currentHP*1.0/this->getHp();
    if(ratio>=0.3&&ratio<0.6){
        qDebug()<<"技能1";
        return 3;
    }else if(ratio>=0.6&&ratio<0.9){
        qDebug()<<"普通攻击";
        return 2;
    }else if(ratio>=0.1&&ratio<0.3){
        qDebug()<<"技能二";
        return 4;
    }else if(ratio<=0.1&&ratio>0){
        qDebug()<<"必杀技";
        return 5;
    }else{
        qDebug()<<"嘲讽";
        return 1;
    }
}
