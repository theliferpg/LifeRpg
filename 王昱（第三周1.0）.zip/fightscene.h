#ifndef FIGHTSCENE_H
#define FIGHTSCENE_H

#include <QWidget>
#include "monster.h"
#include "player.h"
#include <QProgressBar>
#include <QPushButton>
#include <QSound>
#include <QMediaPlayer>
#include "music.h"
extern Player player;//玩家
class FightScene : public QWidget
{
    Q_OBJECT
public:
    explicit FightScene(Monster*monster, QWidget *parent = nullptr);
    void paintEvent(QPaintEvent *event);
    void widgetsSet();//控件的设置
    void soundSet();//音效设置
    void drawBasic1();
protected:
    //void keyPressEvent(QKeyEvent *event);     // 重写按键事件
signals:
    void backMap();
    void roleFightSignal();
    void BossFightSignal();
    void roleFailSignal();
    void victorySignal();
    void damageSignal(int value,int who);


private slots:
    void roleAction();//主角进度条满后停止进度条，玩家选择行动方式
    void BossAction();//boss进度条满后直接行动
    void FailView();//游戏失败界面
    void victoryView();//游戏胜利界面

    void damageText(int value,int who);//****新添   增加伤害的显示
private:
    Monster* monster;
    QPixmap pixMap;//主画布
    QPixmap pixMap2;//测试
    int roleX=270;//控制进度条
    int BossX=270;
    QTimer *roleTimer;//计时器
    int currentRoleHP;//记录战斗中的主角血量
    int currentMonsterHP;//记录战斗中怪物的血量
    int flag=0;//判断是否战斗结束
    QPushButton *attack;
    QPushButton *run;
    QPushButton *back;
    Music* battleBackSound;//****新添
    Music* failMusic;
    Music* victoryMusic;
    int monsterAction=0;//怪物行为
    int pixMap2flag=0;//判断是否绘图pixmap2
};

#endif // FIGHTSCENE_H
