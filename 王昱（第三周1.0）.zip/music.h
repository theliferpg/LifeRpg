#ifndef MUSIC_H
#define MUSIC_H

#include <QObject>
#include <QMediaPlayer>
#include <QMediaPlaylist>
class Music : public QObject
{
    Q_OBJECT
public:
    //explicit Music(QObject *parent = nullptr);
    Music(QString file);
    void setLoop();
    void setVolume(int value);
    void play();
    void stop();
signals:
private:
    QMediaPlayer* music;
    QString file;
    QMediaPlaylist*playlist;
    int volume=100;
};

#endif // MUSIC_H
