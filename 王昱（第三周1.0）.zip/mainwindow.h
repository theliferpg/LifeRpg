#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "view.h"
#include "fightscene.h"
#include "menuscene.h"
#include "start.h"
#include "music.h"//*****************新加


#include <QMainWindow>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QSound>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    void Clear();

    void AddMapItem(int x, int y, int num);
    void AddPictureItem(int x, int y, QString str);
    void AddPlayerItem(int x, int y, int toward);
public slots:
    void slotMovePlayerItem(int x, int y);
    void slotDrawScene();
    void slotDrawFight(int num);
    void slotBackMapFromFight();
    void slotstartGame();//进入游戏界面
    void slotMenuOut();//弹出菜单栏
    void slotViewOut();//回到主界面
private:
    Ui::MainWindow *ui;

    View *view;
    QGraphicsScene *scene;
    QGraphicsPixmapItem *playerItem;
    FightScene *fightScene;
    Monster* monsters[7];
    menuscene *Menuscene;//菜单界面
    startscene *Start;//开始界面
    bool getMonstersFromFile();
    void initMap();
    Music* music;//********新添
};
#endif // MAINWINDOW_H
