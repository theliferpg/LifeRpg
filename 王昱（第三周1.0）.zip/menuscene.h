#ifndef MENUSCENE_H
#define MENUSCENE_H
#include<QWidget>
#include<QPushButton>
#include<QDebug>
#include "ui_mainwindow.h"
#include <QPainter>

class menuscene : public QWidget
{
    Q_OBJECT
public:
    explicit menuscene(QWidget *parent = nullptr);
    void widgetSet();
    void paintEvent(QPaintEvent *event);
    void SetFoucs();

signals:
    void viewOut();

public slots:
    void menuOut();

private:
    QPushButton *saveButton;
    QPushButton *quitButton;
    QPushButton *backButton;
    QPixmap pixMap;

    QPushButton *button1;
    QPushButton *button2;
    QPushButton *button3;
    QPushButton *button4;
    QPushButton *button5;
    QPushButton *button6;
    QPushButton *button7;
    QPushButton *button8;
    QPushButton *button9;


};

#endif // MENUSCENE_H
