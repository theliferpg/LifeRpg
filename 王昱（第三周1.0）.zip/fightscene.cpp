#include "fightscene.h"
#include <QLabel>
#include <QPushButton>
#include <QDebug>
#include <QPixmap>
#include <QPainter>
#include <QPoint>
#include <QKeyEvent>
#include <QTimer>
#include <QSound>
#include <QMediaPlayer>
#include <QLineEdit>

FightScene::FightScene(Monster*monster,QWidget *parent) : QWidget(parent)
{
    //获得怪物信息
    this->monster=monster;
    //设置基础属性
    this->resize(640,480);
    //this->setFocusPolicy(Qt::StrongFocus);//设置 焦点在战斗界面
    //设置QPixMap为底层画布
    pixMap=QPixmap(640,480);
    pixMap.fill(Qt::transparent);//设置透明  暂时没有背景图
    pixMap2=QPixmap(640,480);
    pixMap2.fill(Qt::transparent);//设置透明  暂时没有背景图

    //设置主角and怪物HP
    this->currentRoleHP=player.getHp();
    this->currentMonsterHP=monster->getHp();
    //设置背景音乐
    battleBackSound=new Music("qrc:/music/music/battleBack.wav");//战斗
    battleBackSound->setLoop();
    battleBackSound->play();

    failMusic=new Music("qrc:/music/music/defeatFromOCT.wav");//失败
    failMusic->setLoop();
    connect(this,&FightScene::backMap,failMusic,[=](){
        failMusic->stop();
    });

    victoryMusic=new Music("qrc:/music/music/victoryFromOCT.wav");//胜利
    victoryMusic->setLoop();
    connect(this,&FightScene::backMap,victoryMusic,[=](){
        victoryMusic->stop();
    });


    //连接可攻击信号和攻击函数
    connect(this,&FightScene::roleFightSignal,this,&FightScene::roleAction);
    connect(this,&FightScene::BossFightSignal,this,&FightScene::BossAction);
    connect(this,&FightScene::roleFailSignal,this,&FightScene::FailView);
    connect(this,&FightScene::victorySignal,this,&FightScene::victoryView);
    connect(this,SIGNAL(damageSignal(int,int)),this,SLOT(damageText(int,int)));

    widgetsSet();
    //设置QTimer
    roleTimer=new QTimer(this);
    roleTimer->start(100);
    connect(roleTimer,&QTimer::timeout,this,[=](){
        BossX-=this->monster->getSpeed();
        roleX-=player.getSpeed();
        drawBasic1();
//        attack->setFocus();
        update();
    });

}

void FightScene::paintEvent(QPaintEvent *event){
    QPainter painter(this);
    painter.drawPixmap(0,0,640,480,pixMap);
    if(pixMap2flag==1){
          painter.drawPixmap(0,0,640,480,pixMap2);
    }





}
void FightScene::drawBasic1(){
    QPainter painter(&pixMap);
    painter.drawPixmap(0,0,640,480,pixMap);
    if(flag==0){
        pixMap.fill(Qt::transparent);
        QImage image;
        //绘制背景
        image.load(":/fightingBackground/Image/FightingBack/cave1.png");
        painter.drawImage(0,0,image.scaled(this->width(),this->height()));
        //绘制人物和boss
        image.load(":/role/Image/Role/2.png");
        painter.drawImage(450,300,image.scaled(80,80));
        QString Boss=":/Battlers/Image/Battlers/Battlers/7Boss/";
        Boss+=QString::number(this->monster->getID())+".png";
        image.load(Boss);
        painter.drawImage(20,100,image.scaled(350,280).mirrored(true,false));//镜面翻转


        //右上角绘制人物状态（HP之类的）
        image.load(":/role/Image/Role/1.png");
        painter.drawImage(460,10,image);
        QPen pen;
        pen.setWidth(20);
        pen.setColor(Qt::cyan);
        painter.setPen(pen);
        painter.drawLine(510,20,610,20);
        if(currentRoleHP*1.0/player.getHp()*100>=50)
            pen.setColor(Qt::green);
        else if(currentRoleHP*1.0/player.getHp()*100>=20)
            pen.setColor(Qt::yellow);
        else
            pen.setColor(Qt::red);
        painter.setPen(pen);
        if(currentRoleHP<0){
            currentRoleHP=0;//避免反向划线
        }
        painter.drawLine(510,20,510+currentRoleHP*1.0/player.getHp()*100,20);//血条长度=当前血量占总血量的多少*100像素
        pen.setColor(Qt::black);
        painter.setPen(pen);
        painter.drawText(QPoint(510,25),QString::number(currentRoleHP)+"/"+QString::number(player.getHp()));//血量的文字
        //绘制进度条
        pen.setColor(Qt::cyan);
        pen.setWidth(3);
        painter.setPen(pen);
        painter.drawLine(50,40,300,40);
        if(roleX<=30){
            //roleTimer->stop();
            emit roleFightSignal();//发送可攻击信号
            roleX=270;

        }
        if(BossX<=30){
            emit BossFightSignal();//发送可攻击信号
            BossX=270;
        }
        image.load(":/small/Image/smallIcon/skull.png");
        painter.drawImage(BossX,0,image.scaled(30,30));
        image.load(":/small/Image/smallIcon/1.png");
        painter.drawImage(roleX,45,image.scaled(30,30));
    }
}
//控件设置
void FightScene::widgetsSet(){
    attack=new QPushButton(this);
    run=new QPushButton(this);
    back=new QPushButton(this);
    attack->hide();//初始设为不可见
    run->hide();
    back->hide();
    connect(this,&FightScene::roleFightSignal,this,[=](){
        run->show();
        attack->show();
    });
    //攻击按键设置
    attack->setText("攻击");
    attack->move(540,300);
    connect(attack,&QPushButton::clicked,this,[=](){
        int damage=8;
        this->currentMonsterHP-=damage;
        //this->currentMonsterHP-=player.getAttack()*1.0/(1+0.05*monster->getDefend());
        qDebug()<<"你打了Boss一拳"<<currentMonsterHP;


        //****新添
        Music*temp=new Music("qrc:/music/music/swordAttack.WAV");
        temp->play();
        emit damageSignal(damage,0);


        if(currentMonsterHP<=0){
            run->hide();
            attack->hide();
            QTimer* tempTimer=new QTimer(this);
            tempTimer->start(1200);
            connect(tempTimer,&QTimer::timeout,this,[=](){
                tempTimer->stop();
                emit victorySignal();
            });
        }else{
            roleTimer->start(100);
            this->setFocus();
            run->hide();
            attack->hide();
        }
    });
    //逃跑按键设置
    run->setText("逃跑");
    run->move(540,350);
    connect(run,&QPushButton::clicked,this,[=](){
        qDebug()<<"你逃跑了";
        run->hide();
        attack->hide();
        roleTimer->stop();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            emit roleFailSignal();

        });
    });
    //返回地图按键
    back->setText("返回地图");
    back->move(this->width()/2-50,this->height()-50);
    connect(back,&QPushButton::clicked,this,[=](){
        this->hide();
        emit backMap();

    });
}
//****新添   增加伤害的显示
void FightScene::damageText(int value,int who){//value 代表伤害值  who代表受伤的角色  0代表怪物 1代表玩家
    QPalette pa;
    pa.setColor(QPalette::WindowText,Qt::red);
    QFont ft;
    ft.setPointSize(14);
    QLabel* monsterDamageText;
    QLabel* roleDamageText;
    if(who==0){
        monsterDamageText=new QLabel("-"+QString::number(value),this);
        monsterDamageText->setPalette(pa);
        monsterDamageText->setFont(ft);
        monsterDamageText->move(200,380);
        monsterDamageText->show();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            monsterDamageText->hide();
        });
    }else if(who==1){
        roleDamageText=new QLabel("-"+QString::number(value),this);
        roleDamageText->setPalette(pa);
        roleDamageText->setFont(ft);
        roleDamageText->move(450,380);
        roleDamageText->show();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            roleDamageText->hide();
        });
    }



}


//以下都是槽函数
void FightScene::roleAction(){

    roleTimer->stop();
    attack->setFocus();//每次重新设置攻击键为焦点
}

void FightScene::BossAction(){

    //****新添
    Music*temp=new Music("qrc:/music/music/monsterAttack.wav");
    temp->play();

    int monsterAction=monster->action(currentMonsterHP);//****1代表嘲讽 2代表普通攻击 3代表技能1 4代表必杀技
    if(monsterAction==1){
        QPainter painter(&pixMap2);
        pixMap2.fill(Qt::transparent);
        pixMap2flag=1;
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            pixMap2flag=0;
        });
        QPen pen;
        pen.setColor(Qt::red);
        painter.setPen(pen);
        painter.setFont(QFont("Microsoft YaHei",20,75));
        painter.drawText(QPoint(60,450),monster->getName()+"嘲讽道："+monster->getSneer());
    }else if(monsterAction==2){
        //攻击
        int damage=3;
        qDebug()<<"Boss打了你一拳"<<currentRoleHP;
        //currentRoleHP-=monster->getAttack()/(1+0.05*player.getDefend());//攻击伤害计算  attack/(1+n*defend)  此处n=0.05  可设置  n越大护甲减免伤害效益越高
        currentRoleHP-=damage;
        emit damageSignal(damage,1);
        //动画
        QPainter painter(&pixMap2);
        pixMap2.fill(Qt::transparent);
        pixMap2flag=1;
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            pixMap2flag=0;
        });
        QPen pen;
        pen.setColor(Qt::red);
        painter.setPen(pen);
        painter.setFont(QFont("Microsoft YaHei",20,75));
        painter.drawText(QPoint(60,450),monster->getName()+"使用了普通攻击");
    }
    else if(monsterAction==3){
        //攻击
        int damage=10;
        qDebug()<<"Boss打了你一拳"<<currentRoleHP;
        //currentRoleHP-=monster->getAttack()/(1+0.05*player.getDefend());//攻击伤害计算  attack/(1+n*defend)  此处n=0.05  可设置  n越大护甲减免伤害效益越高
        currentRoleHP-=damage;
        emit damageSignal(damage,1);
        //动画
        QPainter painter(&pixMap2);
        pixMap2.fill(Qt::transparent);
        pixMap2flag=1;
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            pixMap2flag=0;
        });
        QPen pen;
        pen.setColor(Qt::red);
        painter.setPen(pen);
        painter.setFont(QFont("Microsoft YaHei",20,75));
        painter.drawText(QPoint(60,450),monster->getName()+"使用了技能1");
    }
    else if(monsterAction==4){
        //攻击
        int damage=15;
        qDebug()<<"Boss打了你一拳"<<currentRoleHP;
        //currentRoleHP-=monster->getAttack()/(1+0.05*player.getDefend());//攻击伤害计算  attack/(1+n*defend)  此处n=0.05  可设置  n越大护甲减免伤害效益越高
        currentRoleHP-=damage;
        emit damageSignal(damage,1);
        //动画
        QPainter painter(&pixMap2);
        pixMap2.fill(Qt::transparent);
        pixMap2flag=1;
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            pixMap2flag=0;
        });
        QPen pen;
        pen.setColor(Qt::red);
        painter.setPen(pen);
        painter.setFont(QFont("Microsoft YaHei",20,75));
        painter.drawText(QPoint(60,450),monster->getName()+"使用了技能2");
    }
    else {
        //攻击
        int damage=1;
        qDebug()<<"Boss打了你一拳"<<currentRoleHP;
        //currentRoleHP-=monster->getAttack()/(1+0.05*player.getDefend());//攻击伤害计算  attack/(1+n*defend)  此处n=0.05  可设置  n越大护甲减免伤害效益越高
        currentRoleHP-=damage;
        emit damageSignal(damage,1);
        //动画
        QPainter painter(&pixMap2);
        pixMap2.fill(Qt::transparent);
        pixMap2flag=1;
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(1200);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            pixMap2flag=0;
        });
        QPen pen;
        pen.setColor(Qt::red);
        painter.setPen(pen);
        painter.setFont(QFont("Microsoft YaHei",20,75));
        painter.drawText(QPoint(60,450),monster->getName()+"使用了必杀技");
    }
    update();
    //判断角色死亡
    if(currentRoleHP<=0){
        roleTimer->stop();
        QTimer* tempTimer=new QTimer(this);
        tempTimer->start(2000);
        connect(tempTimer,&QTimer::timeout,this,[=](){
            tempTimer->stop();
            emit roleFailSignal();
            roleTimer->stop();
        });
    }


}

void FightScene::FailView(){
    //******新添
    battleBackSound->stop();
    failMusic->play();



    QImage image;
    image.load(":/fightingBackground/Image/GameOver/gameover.png");
    QPainter painter(&pixMap);
    painter.drawImage(QPoint(0,0),image.scaled(this->width(),this->height()));
    flag=1;//战斗结束
    update();
    back->show();
    back->setFocus();
    attack->hide();
    run->hide();

}
//胜利结算界面  暂时先这样
void FightScene::victoryView(){
    //******新添
    battleBackSound->stop();
    victoryMusic->play();



    QImage image;
    image.load(":/fightingBackground/Image/GameOver/victory.png");
    QPainter painter(&pixMap);
    pixMap.fill(Qt::transparent);
    QPen pen;
    pen.setColor(Qt::cyan);
    painter.setPen(pen);
    QBrush brush(Qt::cyan);
    brush.setStyle(Qt::Dense3Pattern);
    painter.setBrush(brush);
    painter.drawRect(QRect(0,0,this->width(),this->height()));
    painter.drawImage(QPoint(0,0),image);
    flag=1;//战斗结束
    update();
    back->show();
    back->setFocus();
    attack->hide();
    run->hide();


}
