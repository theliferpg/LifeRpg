#include "music.h"
#include "player.h"
extern Player player;
Music::Music(QString file){
    this->file=file;
    this->volume=player.GetVolume();
    music=new QMediaPlayer();
    music->setMedia(QUrl(file));//   这种形式    "qrc:/music/music/battleBack.wav"
}
void Music::setLoop(){
    playlist= new QMediaPlaylist;
    playlist->addMedia(QUrl(file));
    playlist->setCurrentIndex(1);
    playlist->setPlaybackMode(QMediaPlaylist::CurrentItemInLoop);
    music->setPlaylist(playlist);
};
void  Music::setVolume(int value){
    volume=value;
    music->setVolume(volume);
}
void  Music::play(){
    music->setVolume(volume);
    music->play();
}
void  Music::stop(){
    music->stop();
}
