#ifndef MONSTER_H
#define MONSTER_H

#include "Role.h"
#include <QString>
class Monster : public Role
{
public:
    Monster();
    ~Monster();
    //************
    void setSneer(QString sneer){this->sneer=sneer;};
    void setID(int ID){this->ID=ID;};

    QString getSneer(){return this->sneer;};
    int getID(){return this->ID;};

    int action(int currentHP);//********怪物行为进阶

// 细节部分暂未想好，等实现了具体功能再看
private:
    int ID;
    QString sneer;
};

#endif // MONSTER_H
